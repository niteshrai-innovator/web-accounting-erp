<?php
/**
 * Handle Setting Api Actions
 *
 * @package WkAcctErp\Api\Routes\Route
 */
namespace WkAcctErp\Api\Routes\Route;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use WP_REST_Controller;

class WkAcct_Erp_Setting_Route extends WP_REST_Controller {

    /**
	 * $namespace.
	 *
	 * @var string
	 */
	protected $namespace;

    /**
	 * $rest_base.
	 *
	 * @var string
	 */
	protected $rest_base;

	public function __construct() {
		$this->namespace = 'erp-addon/v1';
		$this->rest_base = 'settings';
	}

	/**
	 * Register Routes
	 */
	public function register_routes() {
        // Get Project Info.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_permission_check' ),
					'args'                => $this->get_collection_params(),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_items' ),
					'permission_callback' => array( $this, 'get_permission_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( true ),
				),
			)
		);
    }

    /**
	 * Get items response
	 */
	public function get_items( $request ) {
		$response = array(
			'project_title'      => get_option( 'wkwp_erp_addon_settings_page_title', '' ),
			'project_date_first' => get_option( 'wkwp_erp_addon_settings_project_date_first', '' ),
			'project_date_last'  => get_option( 'wkwp_erp_addon_settings_project_date_second', '' ),
            'assign_single_customer'  => get_option( 'wkwp_erp_addon_project_assign_single_customer', false ),
		);

		return rest_ensure_response( $response );
	}

    /**
	 * Create item response
	 */
	public function create_items( $request ) {
        global $wpdb;
        $wpdb_obj = $wpdb;
        $post_data   = is_object( $request ) ? $request->get_params() : $request;
        $request_data = !empty($post_data['data']) ? $post_data['data'] : array();
		// Data validation
		$project_title      = isset( $request_data['project_title'] ) ? sanitize_text_field( $request_data['project_title'] ) : '';
		$project_date_first = isset( $request_data['project_date_first'] ) ? sanitize_text_field( $request_data['project_date_first'] ) : '';
		$project_date_last  = isset( $request_data['project_date_last'] ) ? sanitize_text_field( $request_data['project_date_last'] ) : '';
        $assign_single_customer  = isset( $request_data['assign_single_customer'] ) ? sanitize_text_field( $request_data['assign_single_customer'] ) : false;
        $project_slug = title_slugify($project_title);

        $erp_product_type_table_name = $wpdb_obj->prefix.'wkacct_erp_product_types';
        $product_type_table_exist =  "SHOW TABLES LIKE '".$erp_product_type_table_name."'";
        $prod_type_find = $wpdb_obj->get_results($product_type_table_exist);

        if( $prod_type_find ) {
            $prev_type_title = get_option( 'wkwp_erp_addon_settings_page_title', '' );
            $prev_type_slug = title_slugify($prev_type_title);

            $created_at = date( 'Y-m-d H:i:s' );

            $product_type_check =  $wpdb_obj->get_row(
                $wpdb_obj->prepare(
                    "SELECT * FROM {$erp_product_type_table_name} where slug = %s",
                    $prev_type_slug
                ),
                OBJECT
            );

            if($product_type_check) {
                $type_id = $product_type_check->id;
                $wpdb_obj->update(
                    $erp_product_type_table_name,
                    [
                        'name'        => $project_title,
                        'slug'        => $project_slug,
                        'updated_at'  => $created_at,
                        'updated_by'  => get_current_user_id(),
                    ],
                    [
                        'id' => $type_id,
                    ]
                );
            } else {
                $wpdb_obj->insert(
                    $erp_product_type_table_name,
                    array(
                        'name'        => $project_title,
                        'slug'        => $project_slug,
                        'created_at'  => $created_at,
                        'created_by'  => get_current_user_id(),
                    )
                );
            }

        }

		// Save option data into WordPress
		update_option( 'wkwp_erp_addon_settings_page_title', $project_title );
		update_option( 'wkwp_erp_addon_settings_project_date_first', $project_date_first );
		update_option( 'wkwp_erp_addon_settings_project_date_second', $project_date_last );
        update_option( 'wkwp_erp_addon_project_assign_single_customer', $assign_single_customer );


		$response = array(
			'project_title'      => $project_title,
			'project_date_first' => $project_date_first,
			'project_date_last'  => $project_date_last,
            'assign_single_customer'  => $assign_single_customer,
		);

		return rest_ensure_response( $response );

	}

    /**
	 * Retrives the query parameters for the items collection
	 */
	public function get_collection_params() {
		return array();
	}

	/**
	 * Get items permission check
	 */
	public function get_permission_check( $request ) {
		return true;
	}

	/**
     * Prepare a response for inserting into a collection.
     *
     * @param WP_REST_Response $response response object
     *
     * @return array response data, ready for insertion into collection data
     */
    public function prepare_response_for_collection( $response ) {
        if ( ! ( $response instanceof \WP_REST_Response ) ) {
            return $response;
        }

        $data   = (array) $response->get_data();
        $server = rest_get_server();

        if ( method_exists( $server, 'get_compact_response_links' ) ) {
            $links = call_user_func( [ $server, 'get_compact_response_links' ], $response );
        } else {
            $links = call_user_func( [ $server, 'get_response_links' ], $response );
        }

        if ( ! empty( $links ) ) {
            $data['_links'] = $links;
        }

        return $data;
    }

	/**
     * Format item's collection for response
     *
     * @param object $response
     * @param object $request
     * @param array  $items
     * @param int    $total_items
     *
     * @return object
     */
    public function format_collection_response( $response, $request, $total_items ) {
        if ( $total_items === 0 ) {
            return $response;
        }

        // Store pagation values for headers then unset for count query.
        $per_page = (int) ( ! empty( $request['per_page'] ) ? $request['per_page'] : 20 );
        $page     = (int) ( ! empty( $request['page'] ) ? $request['page'] : 1 );

        $response->header( 'X-WP-Total', (int) $total_items );

        $max_pages = ceil( $total_items / $per_page );

        $response->header( 'X-WP-TotalPages', (int) $max_pages );
        $base = add_query_arg( $request->get_query_params(), rest_url( sprintf( '/%s/%s', $this->namespace, $this->rest_base ) ) );

        if ( $page > 1 ) {
            $prev_page = $page - 1;

            if ( $prev_page > $max_pages ) {
                $prev_page = $max_pages;
            }
            $prev_link = add_query_arg( 'page', $prev_page, $base );
            $response->link_header( 'prev', $prev_link );
        }

        if ( $max_pages > $page ) {
            $next_page = $page + 1;
            $next_link = add_query_arg( 'page', $next_page, $base );
            $response->link_header( 'next', $next_link );
        }

        return $response;
    }
}