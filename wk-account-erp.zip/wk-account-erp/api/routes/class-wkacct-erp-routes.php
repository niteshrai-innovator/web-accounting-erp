<?php
/**
 * Api Routes.
 *
 * @package WkAcctErp\Api\Routes
 * @since   1.0.0
 */
namespace WkAcctErp\Api\Routes;

defined( 'ABSPATH' ) || exit;

use WP_REST_Controller;
use WkAcctErp\Api\Routes\Route\WkAcct_Erp_Setting_Route;

if ( ! class_exists( 'WkAcct_Erp_Routes' ) ) {

	/**
	 * Api routes class.
	 */
	class WkAcct_Erp_Routes extends WP_REST_Controller {
        
        /**
         * Construct Function
         */
        public function __construct() {
            add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        }

        /**
         * Register API routes
         */
        public function register_routes() {
            ( new WkAcct_Erp_Setting_Route() )->register_routes();
        }

       
    }
}