<?php
/**
 * Create new Nets order request class
 *
 * @package WkAcctErp\Helper\Dibs\Request\Post
 */

namespace WkAcctErp\Api\Request\Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use WkAcctErp\Api\Request;
use WkAcctErp\Helper;

/**
 * Create new Nets order request class
 */
class WkAcct_Erp_Request_Config extends Request\WkAcct_Erp_Request_Post {

	/**
	 * Class constructor.
	 *
	 * @param array $arguments The request arguments.
	 */
	public function __construct( $arguments = array() ) {
		parent::__construct( $arguments );
		$this->log_title = 'Create Project';
	}

	/**
	 * Get the body for the request.
	 *
	 * @return array
	 */
	protected function get_body() {
		$protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"],0,strpos( $_SERVER["SERVER_PROTOCOL"],'/')));

		
		$request_args['data'] = $this->arguments;
		

		return apply_filters( 'wkwc_dibs_easy_create_order_args', $request_args );
	}


	/**
	 * Get the request url.
	 *
	 * @return string
	 */
	protected function get_request_url() {
		return $this->endpoint . 'erp-addon/v1/settings';
	}
}
