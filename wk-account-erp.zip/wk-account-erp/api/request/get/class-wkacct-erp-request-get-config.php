<?php
/**
 * Create new Nets order request class
 *
 * @package WkAcctErp\Api\Request\Post;
 */

 namespace WkAcctErp\Api\Request\Get;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use WkAcctErp\Api\Request;
use WkAcctErp\Helper;
/**
 * Create new Nets order request class
 */
class WkAcct_Erp_Request_Get_Config extends Request\WkAcct_Erp_Request_Get {
	/**
	 * Class constructor.
	 *
	 * @param array $arguments The request args.
	 */
	public function __construct( $arguments = array() ) {
		parent::__construct( $arguments );
		$this->log_title = 'Get project setting ( admin )';
	}

	/**
	 * Get the request url.
	 *
	 * @return string
	 */
	protected function get_request_url() {
		return $this->endpoint . 'erp-addon/v1/settings';
	}
}
