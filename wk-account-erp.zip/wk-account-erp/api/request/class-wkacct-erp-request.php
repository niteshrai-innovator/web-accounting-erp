<?php
/**
 * Main request class
 *
 * @package WkAcctErp\Api\Request
 */

namespace WkAcctErp\Api\Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use WkAcctErp\Helper\WkAcct_Erp_Logger;

/**
 * Main request class
 */
abstract class WkAcct_Erp_Request {
	/**
	 * The request method.
	 *
	 * @var string
	 */
	protected $method;

	/**
	 * The request title.
	 *
	 * @var string
	 */
	protected $log_title;

	/**
	 * $key. Nets API request key.
	 *
	 * @var string
	 */
	public $key;

	/**
	 * $endpoint. Nets API endpoint.
	 *
	 * @var string
	 */
	public $endpoint;

	/**
	 * The request arguments.
	 *
	 * @var array
	 */
	protected $arguments;

	/**
	 * The plugin settings.
	 *
	 * @var array
	 */
	protected $settings;

	/**
	 * Whether the plugin is in test mode.
	 *
	 * @var string
	 */
	protected $test_mode;

	/**
	 * Class constructor.
	 *
	 * @param array $arguments The request args.
	 */
	public function __construct( $arguments = array() ) {
		$this->arguments = $arguments;
		$this->endpoint = $this->get_endpoint();
	}

	/**
	 * Get the Dibs endpoint.
	 *
	 * @return string
	 */
	protected function get_endpoint() {
		return WKACCT_API_ENDPOINT;
	}

	/**
	 * Get the request headers.
	 *
	 * @return array
	 */
	protected function get_request_headers() {
		return array(
			'Content-type'        => 'application/json',
			'Accept'              => 'application/json',
		);
	}

	/**
	 * Get the user agent.
	 *
	 * @return string
	 */
	protected function get_user_agent() {
		$protocols = array( 'http://', 'http://www.', 'https://', 'https://www.' );
		$url       = str_replace( $protocols, '', get_bloginfo( 'url' ) );
		return apply_filters( 'wkacct_erp_http_useragent', 'WordPress/' . get_bloginfo( 'version' ) . '; ' . iconv( 'UTF-8', 'ASCII//IGNORE', $url ) ) . ' - Plugin/' . WK_ACCT_ERP_VERSION . ' - PHP/' . PHP_VERSION;
	}

	/**
	 * Get the request args.
	 *
	 * @return array
	 */
	abstract protected function get_request_args();

	/**
	 * Get the request url.
	 *
	 * @return string
	 */
	abstract protected function get_request_url();

	/**
	 * Make the request.
	 *
	 * @return object|WP_Error
	 */
	public function request() {
		$url  = $this->get_request_url();
		$args = $this->get_request_args();
		$response = wp_remote_request( $url, $args );
		return $this->process_response( $response, $args, $url );
	}

	/**
	 * Processes the response checking for errors.
	 *
	 * @param object|WP_Error $response The response from the request.
	 * @param array           $request_args The request args.
	 * @param string          $request_url The request url.
	 * @return array|WP_Error
	 */
	protected function process_response( $response, $request_args, $request_url ) {
		
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		if ( $response_code < 200 || $response_code > 299 ) {
			$data          = 'URL: ' . $request_url . ' - ' . wp_json_encode( $request_args );
			$error_message = '';
			// Get the error messages.
			if ( null !== json_decode( $response['body'], true ) ) {
				$errors = json_decode( $response['body'], true );
				foreach ( $errors as $properties ) {
					if ( is_array( $properties ) ) {
						foreach ( $properties as $property ) {
							foreach ( $property as $err_message ) {
								$error_message .= ' ' . $err_message;
							}
						}
					} else {
						$error_message .= ' ' . $properties;
					}
				}
			} else {
				$message       = wp_remote_retrieve_response_message( $response );

				if( '401' == $response_code ){
					$error_message = "Checkout data could not be authorized";
				} else{
					$error_message = "API Error ${response_code}, message : ${message}";
				}
			}
			$return = new \WP_Error( $response_code, $error_message, $data );
		} else {
			$return = json_decode( wp_remote_retrieve_body( $response ), true );
		}

		$this->log_response( $response, $request_args, $request_url );
		return $return;
	}

	/**
	 * Formats error message.
	 *
	 * @param mixed $response WC order id.
	 * @return object
	 */
	public function get_error_message( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$response_body = wp_remote_retrieve_body( $response );
		if ( empty( $response_body ) ) {
			$response_body = 'Response code ' . $response['response']['code'] . '. Message: ' . $response['response']['message'];
		}

		$errors = new WP_Error();
		$errors->add( 'wkacct_erp', $response_body );

		WkAcct_Erp_Logger::log( 'WP Accounts Error Response: ' . stripslashes_deep( wp_json_encode( $response_body ) ) );
		return $errors;
	}

	/**
	 * Logs the response from the request.
	 *
	 * @param array|WP_Error $response The response from the request.
	 * @param array          $request_args The request args.
	 * @param string         $request_url The request URL.
	 *
	 * @return void
	 */
	protected function log_response( $response, $request_args, $request_url ) {
		$method = $this->method;
		$title  = $this->log_title;
		$code   = wp_remote_retrieve_response_code( $response );

		$body = json_decode( $response['body'], true );

		$log = WkAcct_Erp_Logger::format_log( $body, $method, $title, $request_args, $request_url, $response, $code );
		WkAcct_Erp_Logger::log( $log );
	}
}
