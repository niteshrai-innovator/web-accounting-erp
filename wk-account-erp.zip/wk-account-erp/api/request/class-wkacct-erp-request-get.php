<?php
/**
 * Base class for all GET requests.
 *
 * @package WkAcctErp\Api
 */

namespace WkAcctErp\Api\Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use WkAcctErp\Api\Request\WkAcct_Erp_Request;
/**
 *  The main class for GET requests.
 */
abstract class WkAcct_Erp_Request_Get extends WkAcct_Erp_Request {
	/**
	 * Class constructor.
	 *
	 * @param array $arguments The request arguments.
	 */
	public function __construct( $arguments = array() ) {
		parent::__construct( $arguments );
		$this->method   = 'GET';
	}

	/**
	 * Builds the request args for a GET request.
	 *
	 * @return array
	 */
	public function get_request_args() {
		return array(
			'headers'    => $this->get_request_headers(),
			'user-agent' => $this->get_user_agent(),
			'method'     => $this->method,
		);
	}
}
