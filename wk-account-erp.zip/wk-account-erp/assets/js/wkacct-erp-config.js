// Admin End Js

;(function ($) {

    $(document).ready(function () {
        console.log('config running');
        $('.sub-sub-menu a').click(function(){
            $('.panel').hide();
            $('.sub-sub-menu a.router-link-active').removeClass('router-link-active');
            $(this).addClass('router-link-active');
            
            var panel = $(this).attr('href');
            $(panel).fadeIn(1000);
            
            return false;  // prevents link action
           
        });  // end click 


        $('.wk-addon-wperp-table .row-actions a.dropdown-trigger').click(function(){
            console.log('rururuur');
            $(this).next().toggleClass('show').css({
                "position": "absolute",
                "inset": "auto 0px 0px auto",
                "margin": "0px",
                "transform": "translate3d(-35px, -75.5px, 0px)"
            });
           
        });  // end click 

        // Add click event to the document
        $(document).click(function(event) {
            // Check if the clicked element is not inside #myElement
            if (!$(event.target).closest('.wk-addon-wperp-table .row-actions a.dropdown-trigger').next('.show').length) {
                // Remove the 'highlight' class
                $('.wk-addon-wperp-table .row-actions a.dropdown-trigger').next().removeClass('show');
            }
        });

        
       
        $('.sub-sub-menu li:first a').click();

        $('#wkwp-erp-addon-general-setting-form').on('submit', function(event) {
            event.preventDefault();
            // Create FormData object
            var formData = new FormData(this);

            // Add any additional data if needed
            formData.append("action", "wkacct_general_settion_action");
            formData.append("nonce", WkacctErp.nonce);
            $.ajax({
                url: WkacctErp.ajaxUrl,
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    $('#wkacct_general_submit').attr('disabled', 'disabled');
                    $('#wkacct_general_submit').val('wait...');
                },
                success: function(data) {
                    $('#wkacct_general_submit').attr('disabled', false);
                    if (data.error != '') {
                        $('#wkwp-erp-addon-general-message').html(data.error);
                    }
                }
            })
        });


        // Open Modal on Button Click
        $("#wperp-addon-email-format-new").click(function() {
            $("#wperp-email-modal").css("display", "block");
        });

        // Close Modal
        $("#wperp-email-modal .modal-close").click(function() {
            $("#wperp-email-modal").css("display", "none");
        });


        // Open Modal on Button Click
        $("#wperp-addon-add-new-pdf-theme").click(function() {
            $("#wperp-pdftheme-modal").css("display", "block");
        });

        // Close Modal
        $("#wperp-pdftheme-modal .modal-close").click(function() {
            $("#wperp-pdftheme-modal").css("display", "none");
        });


        // Open Modal on Button Click
        $("#wperp-addon-paypal-profile-new").click(function() {
            $("#wperp-paypal-profile-modal").css("display", "block");
        });

        // Close Modal
        $("#wperp-paypal-profile-modal .modal-close").click(function() {
            $("#wperp-paypal-profile-modal").css("display", "none");
        });



    })

})(jQuery);
