// Admin End Js

;(function ($) {

    document.addEventListener('DOMContentLoaded', function() {
        var datepickerElements = document.querySelectorAll('.datepicker');

        datepickerElements.forEach(function(element) {
            var picker = new Pikaday({
                field: element,
                format: 'YYYY-MM-DD', // Adjust the format as needed
                // Add more options if needed
            });
        });
    });

    $(document).ready(function () {

        if ($('.wkacct-erp-select2').length) {
            $('.wkacct-erp-select2').select2();
        }

        console.log('jquery is working');
        
        $('.wk-addon-wperp-table .row-actions a.dropdown-trigger').click(function(){
            console.log('rururuur');
            $(this).next().toggleClass('show').css({
                "position": "absolute",
                "inset": "auto 0px 0px auto",
                "margin": "0px",
                "transform": "translate3d(-18px, 32px, 18px)"
            });
           
        });  // end click 

        // Add click event to the document
        $(document).click(function(event) {
            // Check if the clicked element is not inside #myElement
            if (!$(event.target).closest('.wk-addon-wperp-table .row-actions a.dropdown-trigger').next('.show').length) {
                // Remove the 'highlight' class
                $('.wk-addon-wperp-table .row-actions a.dropdown-trigger').next().removeClass('show');
            }
        });

        $('.wperp-selected-option').click(function(){
            $(this).next().toggleClass('show');
           
        });  // end click 

        // Add click event to the document
        $(document).click(function(event) {
            // Check if the clicked element is not inside #myElement
            if (!$(event.target).closest('.wperp-selected-option').next('.show').length) {
                // Remove the 'highlight' class
                $('.wperp-selected-option').next().removeClass('show');
            }
        });

        // Sample data
        // var data = {
        //     labels: ['Category 1', 'Category 2', 'Category 3'],
        //     datasets: [{
        //         data: [30, 50, 20],
        //         backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
        //     }]
        // };

        // // Chart options
        // var options = {
        //     responsive: true,
        // };

        // // Get the canvas element
        // var ctx = document.getElementById('payment_chart').getContext('2d');

        // // Create and display the pie chart
        // var myPieChart = new Chart(ctx, {
        //     type: 'pie',
        //     data: data,
        //     options: options
        // });


        function makeChart(chart_id, chart_data = {}) {
            console.log(chart_id, chart_data);
            let self = this;
            let colors = chart_data.colors;
            let labels = chart_data.labels;
            let data = chart_data.data;
            let bgColor = colors;
            let dataChart = {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: bgColor
                }]
            };
            let config = {
                type: 'doughnut',
                data: dataChart,
                options: {
                    maintainAspectRatio: true,
                    aspectRatio: 1.8,
                    cutout: '45%',
                    plugins: {
                        // Custom Tooltip
                        tooltip: {
                            yPadding: 10,
                            callbacks: {
                                label: function(context) {
                                    let total = 0;
                                    const { dataset, label, raw, formattedValue } = context;

                                    dataset.data.forEach(function(element) {
                                        if (element !== 0) {
                                            total += parseFloat(element);
                                        }
                                    });

                                    const percentTxt = Math.round(raw / total * 100);
                                    return `${label} : ${formattedValue} (${percentTxt}%)`;
                                }
                            }
                        },

                        // Custom Legend Generator
                        legend: {
                            display: true,
                            labels: {
                                generateLabels: function(chart) {
                                    const { data } = chart;
                                    const { datasets, labels } = data;

                                    if (! datasets.length) {
                                        return [];
                                    }

                                    let text = [];
                                    text.push('<ul class="chart-labels-list">');

                                    for (let i = 0; i < datasets[0].data.length; ++i) {
                                        text.push(`<li>
                                            <div class="label-icon-wrapper">
                                                <span class="chart-label-icon" style="background-color:${datasets[0].backgroundColor[i]}"></span>
                                            </div>
                                            <div class="chart-label-values">
                                        `);

                                        if (datasets[0].data[i]) {
                                            if (chart_id === 'payment') {
                                                text.push(`<span class="chart-value">${datasets[0].data[i]}</span><br>`);
                                            } else {
                                                text.push(`<span class="chart-value">${datasets[0].data[i]}</span>`);
                                            }
                                        }

                                        if (labels[i]) {
                                            text.push(`<span class="chart-label"> ${labels[i]}</span>`);
                                        }

                                        text.push(`</div></li>`);
                                    }

                                    text.push(`</ul>`);

                                    // Set the custom legend HTML
                                    document.getElementById(chart_id + '_legend').innerHTML = text.join('');

                                    // We don't need to manage legend items,
                                    // as if we're just updated the Inner HTML element
                                    return [];
                                }
                            },
                        }
                    }
                }
            };

            setTimeout(function() {
                let chartCtx = document.getElementById(chart_id + '_chart');

                if (chartCtx !== null) {
                    chartCtx = chartCtx.getContext('2d');
                    new Chart(chartCtx, config);
                }
            }, 1000);
        }


        function payment_chart_data() {

            return {
                chartStatus: {
                    colors: ['#208DF8', '#E9485E', '#FF9900', '#2DCB67', '#9c27b0', '#e3ff66' ],
                    labels: [],
                    values: []
                },
                chartPayment: {
                    colors: ['#40c4ff', '#e91e63'],
                    labels: [ 'Received','Outstanding' ],
                    values: [],
                    outstanding: 0
                }
            };
        } 
        
        function getSalesChartData(filters = {}) {
            let payment_data = payment_chart_data();
            HTTP.get('/transactions/sales/chart-payment', {
                params: {
                    start_date: filters.start_date,
                    end_date: filters.end_date
                }
            }).then(response => {
                payment_data.chartPayment.outstanding = response.data.outstanding;

                payment_data.chartPayment.values.push(
                    response.data.received,
                    response.data.outstanding
                );
            });
        }

        var payment_data = payment_chart_data();

        payment_data.chartPayment.values.push(
            {"received":"239.00","outstanding":"729.14"}
        );

        var transaction_chart_data = {
            title:'Payment',
            labels:payment_data.chartPayment.labels,
            colors:payment_data.chartPayment.colors,
            data:payment_data.chartPayment.values
        }



        makeChart('payment', transaction_chart_data);
        
    })

})(jQuery);
