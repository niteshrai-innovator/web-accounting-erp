<?php
/**
 * Plugin Name: WP Accounts
 * Description: This Erp module allows you to manage accounts detail of your firm.
 * Version: 1.0.0
 * Author: Webkul
 * Author URI: https://webkul.com
 * Domain Path: /i18n/languages/
 * Text Domain: wk-acct-erp
 * Requires PHP: 7.2
 * Requires at least: 5.0
 *
 * @package WkAcctErp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit(); // No direct access allowed
}

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define Constants.
defined( 'WK_ACCT_ERP_FILE' ) || define( 'WK_ACCT_ERP_FILE', __FILE__ );
defined( 'WK_ACCT_ERP_NAME' ) || define( 'WK_ACCT_ERP_NAME', 'WP Accounts' );

require_once __DIR__ . '/inc/autoload.php';

// Include the main WK_Acct_Erp class.
if ( ! class_exists( 'WK_Acct_Erp', false ) ) {
	include_once dirname( WK_ACCT_ERP_FILE ) . '/includes/class-wkacct-erp.php';
}

/**
 * Returns the main instance of WC.
 *
 * @return WK_Acct_Erp
 */
function wkacct_erp() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return WK_Acct_Erp::instance();
}

// Global for backwards compatibility.
$GLOBALS['wkacct_erp'] = wkacct_erp();
