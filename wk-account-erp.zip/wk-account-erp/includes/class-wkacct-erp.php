<?php
/**
 * Main setup file.
 *
 * @package WooCommerce Product Return RMA
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
use WkAcctErp\Api\Routes;

/**
 * Main WK_Acct_Erp Class.
 *
 * @class WK_Acct_Erp
 */
final class WK_Acct_Erp {

	/**
	 * Define Plugin Version
	 */
	public $version = '1.0.0';

	/**
	 * Api class.
	 *
	 * @var WkAcct_Erp_Api_Handler
	 */
	public $api;

	/**
	 * The single instance of the class.
	 *
	 * @var $instance
	 * @since 1.0
	 */
	protected static $instance = null;

	/**
	 * Main WK_Acct_Erp Instance.
	 *
	 * Ensures only one instance of WK_Acct_Erp is loaded or can be loaded.
	 *
	 * @static
	 *
	 * @return WK_Acct_Erp - Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * WK_Acct_Erp Constructor.
	 */
	public function __construct() {
		$this->wkacct_erp_define_constants();
		$this->wkacct_erp_init_hooks();
		$this->wkacct_erp_includes();
		$this->define_time_constant();
	}

	/**
	 * Define WK_ACCT_ERP Constants.
	 */
	private function wkacct_erp_define_constants() {
		defined( 'WK_ACCT_ERP_VERSION' ) || define( 'WK_ACCT_ERP_VERSION', $this->version );
		defined( 'WK_ACCT_ERP_ABSPATH' ) || define( 'WK_ACCT_ERP_ABSPATH', dirname( WK_ACCT_ERP_FILE ) . '/' );
		defined( 'WK_ACCT_ERP_PLUGIN_BASE' ) || define( 'WK_ACCT_ERP_PLUGIN_BASE', plugin_basename( WK_ACCT_ERP_FILE ) );
		defined( 'WK_ACCT_ERP_PLUGIN_FILE' ) || define( 'WK_ACCT_ERP_PLUGIN_FILE', plugin_dir_path( WK_ACCT_ERP_FILE ) );
		defined( 'WK_ACCT_ERP_PLUGIN_URL' ) || define( 'WK_ACCT_ERP_PLUGIN_URL', plugin_dir_url( WK_ACCT_ERP_FILE ) );

		defined( 'WK_ACCT_ERP_ASSETS' ) || define( 'WK_ACCT_ERP_ASSETS', WK_ACCT_ERP_PLUGIN_URL. '/assets' );

		defined( 'WK_ACCT_ERP_NONCE' ) || define( 'WK_ACCT_ERP_NONCE', 'b?le*;K7.T2jk_*(+3&[G[xAc8O~Fv)2T/Zk9N:GKBkn$piN0.N%N~X91VbCn@.4' );
		defined( 'WKACCT_API_ENDPOINT' ) || define( 'WKACCT_API_ENDPOINT', home_url().'/wp-json/' );
	}

	public function define_time_constant() {
		defined( 'MINUTE_IN_SECONDS' ) || define( 'MINUTE_IN_SECONDS', 60 );
		defined( 'HOUR_IN_SECONDS' ) || define( 'HOUR_IN_SECONDS', 3600 );
		defined( 'DAY_IN_SECONDS' ) || define( 'DAY_IN_SECONDS', 86400 );
		defined( 'WEEK_IN_SECONDS' ) || define( 'WEEK_IN_SECONDS', 604800 );
		defined( 'MONTH_IN_SECONDS' ) || define( 'MONTH_IN_SECONDS', 2592000 );
		defined( 'YEAR_IN_SECONDS' ) || define( 'YEAR_IN_SECONDS', 31536000 );
	}

	/**
	 * Hook into actions and filters.
	 *
	 * @since 2.3
	 */
	private function wkacct_erp_init_hooks() {
		register_activation_hook( WK_ACCT_ERP_FILE, array( 'Wk_Acct_Erp_Install', 'wkacct_erp_install' ) );
		register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
		add_action( 'init', array( $this, 'wkacct_erp_load_plugin_textdomain' ), 0 );
		add_action( 'before_woocommerce_init', array( $this, 'wkacct_erp_is_wc_hpos_compatible' ) );
	}

	/**
	 * Function include
	 */
	public function wkacct_erp_includes() {
		include_once WK_ACCT_ERP_ABSPATH . 'includes/class-wkacct-erp-install.php';
		include_once WK_ACCT_ERP_ABSPATH . 'helper/functions/core-function.php';
		new Routes\WkAcct_Erp_Routes();
		$this->api = new Helper\WkAcct_Erp_Api_Handler();
	}

	/**
	 * Load Localization files.
	 *
	 * Note: the first-loaded translation file overrides any following ones if the same translation is present.
	 */
	public function wkacct_erp_load_plugin_textdomain() {
		load_plugin_textdomain( 'wk-acct-erp', false, plugin_basename( dirname( WK_ACCT_ERP_FILE ) ) . '/languages' );
	}

	/**
	 * Declares WooCommerce HPOS compatibility.
	 *
	 * @return void
	 */
	public function wkacct_erp_is_wc_hpos_compatible() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WK_ACCT_ERP_FILE, true );
		}
	}

	/**
	 * Merge user defined arguments into defaults array.
	 *
	 * This function is similar to WordPress wp_parse_args().
	 * It's support multidimensional array.
	 *
	 * @param  array $args args.
	 * @param  array $defaults Optional.
	 *
	 * @return array
	 */
	public function wkacct_erp_parse_args( &$args, $defaults = array() ) {
		$args     = (array) $args;
		$defaults = (array) $defaults;
		$r        = $defaults;

		foreach ( $args as $k => &$v ) {
			if ( is_array( $v ) && isset( $r[ $k ] ) ) {
				$r[ $k ] = $this->wkacct_erp_parse_args( $v, $r[ $k ] );
			} else {
				$r[ $k ] = $v;
			}
		}

		return $r;
	}

	/**
	 * Function wkacct_erp_error_print_notification error message template
	 *
	 * @param mixed $message message.
	 */
	public function wkacct_erp_error_print_notification( $message ) {
		if ( is_array( $message ) && count( $message ) > 0 ) {
			foreach ( $message as $error ) { ?>
		<div class='notice notice-error is-dismissible'>
			<p><?php echo esc_html( $error ); ?></p>
		</div>
				<?php
			}
		} else {
			?>
		<div class='notice notice-error is-dismissible'>
			<p><?php echo esc_html( $message ); ?></p>
		</div>
			<?php
		}
	}

	/**
	 * Function wkacct_erp_success_print_notification success message template
	 *
	 * @param mixed $message message.
	 */
	public function wkacct_erp_success_print_notification( $message ) {
		?>
		<div class='notice notice-success is-dismissible'>
			<p><?php echo esc_html( $message ); ?></p>
		</div>
		<?php
	}

}
