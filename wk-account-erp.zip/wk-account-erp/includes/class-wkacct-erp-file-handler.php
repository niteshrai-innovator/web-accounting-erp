<?php
/**
 * File Handler.
 *
 * @package WkAcctErp\Includes
 * @since   1.0.0
 */

namespace WkAcctErp\Includes;

defined( 'ABSPATH' ) || exit(); // Exit if access directly.

/**
 * File handler class.
 */
class WkAcct_Erp_File_Handler {

	/**
	 * File handler construct.
	 */
	public function __construct() {
		if ( is_admin() ) {
			/**
			 * Admin Hook Handler
			 */
			new Admin\WkAcct_Erp_Admin_Hooks();

		}
	}
}
