<?php
/**
 * Installation related functions and actions.
 *
 * @package WooCommerce Product Return RMA
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit(); // Exit if access directly.

use WkAcctErp\Includes;
/**
 * Wk_Acct_Erp_Install Class.
 */
class Wk_Acct_Erp_Install {

	/**
	 * Hook in tabs.
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'wkacct_erp_load_plugin' ) );
		add_filter( 'plugin_action_links_' . WK_ACCT_ERP_PLUGIN_BASE, array( __CLASS__, 'wkacct_erp_plugin_action_links' ) );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'wkacct_erp_plugin_row_meta' ), 10, 2 );
	}

	/**
	 * Includes function.
	 */
	public static function wkacct_erp_load_plugin() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			// Add WooCommerce dependency Message.
			deactivate_plugins( basename( __FILE__ ) );

			$error  = __( '<h1>An Error Occured</h1>', 'wk-acct-erp' );
			$error .= __( '<h2>The WP Accounts plugin requires Woocommerce to be installed and active.</h2>', 'wk-acct-erp' );

			wp_die(
				wp_kses_post( $error ),
				esc_html__( 'Plugin Activation Error', 'wk-acct-erp' ),
				array(
					'response'  => 200,
					'back_link' => true,
				)
			);

			return;
		} else {
			$is_installed = get_option( 'wk_acct_erp_is_installed' );

			if ( ! $is_installed ) {
				update_option( 'wk_acct_erp_is_installed', time() );
			}

			update_option( 'wk_acct_erp_is_installed', WK_ACCT_ERP_VERSION );
			new Includes\WkAcct_Erp_File_Handler();
		}
	}

	/**
	 * Show action links on the plugin screen.
	 *
	 * @param mixed $links Plugin Action links.
	 *
	 * @return array
	 */
	public static function wkacct_erp_plugin_action_links( $links ) {
		$action_links = array(
			'settings' => '<a href="' . admin_url( 'admin.php?page=wkacct-erp-setting' ) . '" aria-label="' . esc_attr__( 'Settings', 'wk-acct-erp' ) . '">' . esc_html__( 'Settings', 'wk-acct-erp' ) . '</a>',
		);

		return array_merge( $action_links, $links );
	}

	/**
	 * Show row meta on the plugin screen.
	 *
	 * @param mixed $links Plugin Row Meta.
	 * @param mixed $file  Plugin Base file.
	 *
	 * @return array
	 */
	public static function wkacct_erp_plugin_row_meta( $links, $file ) {

		if ( WK_ACCT_ERP_PLUGIN_BASE !== $file ) {
			return $links;
		}

		$support_url = apply_filters( 'wkacct_erp_support_url', 'https://webkul.uvdesk.com/en/' );

		$row_meta = array(
			'support' => '<a href="' . esc_url( $support_url ) . '" aria-label="' . esc_attr__( 'Support', 'wkwc_rma' ) . '">' . esc_html__( 'Support', 'wk-acct-erp' ) . '</a>',
		);

		return array_merge( $links, $row_meta );
	}

	/**
	 * Show wc not installed notice.
	 *
	 * @return void
	 */
	public static function wkacct_erp_wc_not_installed_notice() {
		?>
		<div class="error">
			<p><?php echo wp_sprintf( /* Translators: %s woocommerce links */ esc_html__( 'WP Accounts plugin depends on the last version of %s or later to work!', 'wk-acct-erp' ), '<a href="http://www.woothemes.com/woocommerce/" target="_blank">' . esc_html__( 'WooCommerce', 'wk-acct-erp' ) . '</a>' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Set erp_hr_manager role for admin user
	 *
	 * @since 1.0
	 *
	 * @return void
	 */
	public static function wkacct_erp_set_role() {
		$admins = get_users( array( 'role' => 'administrator' ) );

		if ( $admins ) {
			foreach ( $admins as $user ) {
				$user->add_role( 'wk_acct_erp_manager' );
			}
		}
	}


	/**
	 * Create Table Schema
	 *
	 * @return array
	 */
	public static function wkacct_erp_get_schema() {
		global $wpdb;
		$charset_collate = '';
		if ( $wpdb->has_cap( 'collation' ) ) {
			$charset_collate = $wpdb->get_charset_collate();
		}

		$table_schema = array(
			$wpdb->prefix . 'wkacct_erp_posts'      =>
			"CREATE TABLE `{$wpdb->prefix}wkacct_erp_posts` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                post_author bigint(20) unsigned NOT NULL,
                post_customer bigint(20) unsigned NOT NULL,
                post_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                post_date_gmt datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `post_content` longtext,
                post_title text,
                post_status text,
                post_name varchar(200) DEFAULT NULL,
                post_type varchar(20)  NOT NULL DEFAULT 'event',
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_postmeta'     => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_postmeta` (
                meta_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                post_id bigint(20) unsigned DEFAULT NULL,
                meta_key varchar(255) DEFAULT NULL,
                `meta_value` longtext,
                PRIMARY KEY (meta_id),
                KEY `post_id` (`post_id`)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_pdftheme' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_pdftheme` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                `name` varchar(255) DEFAULT NULL,
                template bigint(20) unsigned DEFAULT NULL,
                `status` varchar(10) DEFAULT NULL,
                created_at datetime NOT NULL,
                created_by varchar(200) DEFAULT NULL,
                updated_at datetime NOT NULL,
                updated_by varchar(200) DEFAULT NULL,
                PRIMARY KEY (id),
                KEY `template` (`template`)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_pdftheme_meta' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_pdftheme_meta` (
                meta_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                theme_id bigint(20) unsigned DEFAULT NULL,
                meta_key varchar(255) DEFAULT NULL,
                `meta_value` longtext,
                PRIMARY KEY (meta_id),
                KEY `theme_id` (`theme_id`)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_paypal_profile' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_paypal_profile` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                paypal_id varchar(255) DEFAULT NULL,
                email varchar(255) DEFAULT NULL,
                transactions varchar(200) DEFAULT 0,
                `status` varchar(10) DEFAULT 0,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_paypal_profile_meta' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_paypal_profile_meta` (
                meta_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                profile_id bigint(20) unsigned DEFAULT NULL,
                meta_key varchar(255) DEFAULT NULL,
                `meta_value` longtext,
                PRIMARY KEY (meta_id),
                KEY `profile_id` (`profile_id`)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_credit_email_data' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_credit_email_data` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                `name` varchar(255) DEFAULT NULL,
                to_send varchar(50) DEFAULT NULL,
                invoice_ctrl varchar(200) DEFAULT NULL,
                subject_line varchar(250) DEFAULT NULL,
                `email_body_content` longtext,
                `status` varchar(10) DEFAULT NULL,
                created_by varchar(200) DEFAULT NULL,
                updated_by varchar(200) DEFAULT NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_bank_feed_data' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_bank_feed_data` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                ledger_id bigint(20) unsigned DEFAULT NULL,
                reference varchar(250) DEFAULT NULL,
                `date` datetime NOT NULL,
                `feed_desc` longtext,
                credited varchar(250) DEFAULT NULL,
                debited varchar(250) DEFAULT NULL,
                created_by varchar(200) DEFAULT NULL,
                updated_by varchar(200) DEFAULT NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_bank_feed_meta' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_bank_feed_meta` (
                meta_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                post_id bigint(20) unsigned DEFAULT NULL,
                meta_key varchar(255) DEFAULT NULL,
                `meta_value` longtext,
                PRIMARY KEY (meta_id),
                KEY `post_id` (`post_id`)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_payment_summary' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_payment_summary` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                ref_id bigint(20) unsigned DEFAULT NULL,
                payment_id varchar(250) DEFAULT NULL,
                transaction_id varchar(250) DEFAULT NULL,
                intent varchar(250) DEFAULT NULL,
                `status` varchar(50) DEFAULT NULL,
                `purchase_units` longtext,
                `payer` longtext,
                create_time datetime NOT NULL,
                update_time datetime NOT NULL,
                `links` longtext,
                PRIMARY KEY (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_vat_return_data' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_vat_return_data` (
                id int(11) unsigned NOT NULL AUTO_INCREMENT,
                period_key varchar(250),
                vat_due_sales varchar(250),
                vat_due_acquisitions varchar(250),
                total_vat_due varchar(250),
                vat_reclaimed_curr_period varchar(250),
                net_vat_due varchar(250),
                total_value_sales_exvat varchar(250),
                total_value_purchases_exvat varchar(250),
                total_value_goods_supplied_exvat varchar(250),
                total_acquisitions_exvat varchar(250),
                vat_start_at date,
                vat_end_at date,
                vat_due_date date,
                vat_file_date date,
                `status` varchar(50),
                paid_status varchar(50),
                created_by varchar(50) DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_currency_info' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_currency_info` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(255) DEFAULT NULL,
                `sign` varchar(255) DEFAULT NULL,
                `created_at` date DEFAULT NULL,
                `created_by` varchar(50) DEFAULT NULL,
                `updated_at` date DEFAULT NULL,
                `updated_by` varchar(50) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_financial_years' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_financial_years` (
                id int(11) NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(255) DEFAULT NULL,
                `start_date` date DEFAULT NULL,
                end_date date DEFAULT NULL,
                `description` varchar(255) DEFAULT NULL,
                created_at date DEFAULT NULL,
                created_by varchar(50) DEFAULT NULL,
                updated_at date DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_product_types' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_product_types` (
                id int(11) NOT NULL AUTO_INCREMENT,
                name varchar(255) DEFAULT NULL,
                slug varchar(255) DEFAULT NULL,
                created_at date DEFAULT NULL,
                created_by varchar(50) DEFAULT NULL,
                updated_at date DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_financial_years' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_financial_years` (
                id int(11) NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(255) DEFAULT NULL,
                `start_date` date DEFAULT NULL,
                end_date date DEFAULT NULL,
                `description` varchar(255) DEFAULT NULL,
                created_at date DEFAULT NULL,
                created_by varchar(50) DEFAULT NULL,
                updated_at date DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_ledgers' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_ledgers` (
                id int(11) NOT NULL AUTO_INCREMENT,
                chart_id int(11) DEFAULT NULL,
                category_id int(11) DEFAULT NULL,
                `name` varchar(255) DEFAULT NULL,
                slug varchar(255) DEFAULT NULL,
                code int(11) DEFAULT NULL,
                unused tinyint(1) DEFAULT NULL,
                `system` tinyint(1) DEFAULT NULL,
                created_at date DEFAULT NULL,
                created_by varchar(50) DEFAULT NULL,
                updated_at date DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_opening_balances' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_opening_balances` (
                id int(11) NOT NULL AUTO_INCREMENT,
                financial_year_id int(11) DEFAULT NULL,
                chart_id int(11) DEFAULT NULL,
                ledger_id int(11) DEFAULT NULL,
                `type` varchar(50) DEFAULT NULL,
                debit decimal(20,2) DEFAULT 0,
                credit decimal(20,2) DEFAULT 0,
                created_at date DEFAULT NULL,
                created_by varchar(50) DEFAULT NULL,
                updated_at date DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;",

			$wpdb->prefix . 'wkacct_erp_ledger_details' => "CREATE TABLE `{$wpdb->prefix}wkacct_erp_ledger_details` (
                id int(11) NOT NULL AUTO_INCREMENT,
                ledger_id int(11) DEFAULT NULL,
                trn_no int(11) DEFAULT NULL,
                particulars varchar(255) DEFAULT NULL,
                debit decimal(20,2) DEFAULT 0,
                credit decimal(20,2) DEFAULT 0,
                trn_date date DEFAULT NULL,
                created_at date DEFAULT NULL,
                created_by varchar(50) DEFAULT NULL,
                updated_at date DEFAULT NULL,
                updated_by varchar(50) DEFAULT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;",
		);

		return $table_schema;
	}

	/**
	 * Create Table
	 *
	 * @return void
	 */
	public static function wkacct_erp_create_tables() {

		global $wpdb;

		$wpdb->hide_errors();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_schema = self::wkacct_erp_get_schema();
		foreach ( $table_schema as $table_key => $table_value ) {
			if ( ! self::wkacct_erp_database_table_exists( $table_key ) ) {
				dbDelta( $table_value );
			}
		}
	}

		/**
	 * Function to check if a table exists in a table
	 *
	 * @param string $table_name table name.
	 *
	 * @return mixed
	 */
	public static function wkacct_erp_database_table_exists( $table_name ) {
		global $wpdb;
		$wpdb_obj    = $wpdb;
		$table_exist = "SHOW TABLES LIKE '" . $table_name . "'";
		$table_find  = $wpdb_obj->get_results( $table_exist );

		if ( $table_find ) {
			$sql    = "DESCRIBE $table_name";
			$result = $wpdb_obj->get_results( $sql, ARRAY_A );
			if ( $result ) {
				if ( is_array( $result ) && ! empty( $result ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Install WC.
	 */
	public static function wkacct_erp_install() {
		self::wkacct_erp_create_tables();
		self::wkacct_erp_set_role();
	}

}

Wk_Acct_Erp_Install::init();
