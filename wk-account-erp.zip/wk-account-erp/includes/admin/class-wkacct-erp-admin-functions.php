<?php
/**
 * Admin Functions.
 *
 * @package WkAcctErp\Includes\Admin
 * @since   1.0.0
 */
namespace WkAcctErp\Includes\Admin;

defined( 'ABSPATH' ) || exit;
use WkAcctErp\Helper;
use WkAcctErp\Templates\Admin;
use WkAcctErp\Templates\Admin\Form_Template\Settings;

if ( ! class_exists( 'WkAcct_Erp_Admin_Functions' ) ) {

	/**
	 * Admin functions class.
	 */
	class WkAcct_Erp_Admin_Functions {

		/**
		 * $template_handler
		 *
		 * @var object
		 */
		protected $template_handler;

		/**
		 * Data Handler Object
		 *
		 * @var $data_handler
		 */
		protected $data_handler;

		/**
		 * Config Template Handler Object
		 *
		 * @var $data_handler
		 */
		protected $config_temp;

		/**
		 * Script and style suffix
		 *
		 * @var string
		 */
		protected $suffix;

		/**
		 * Script version number
		 *
		 * @var int
		 */
		protected $version;

		/**
		 * Admin Hook constructor
		 */
		public function __construct() {
			$this->suffix  = '.min';
        	$this->version = WK_ACCT_ERP_VERSION;
			$this->config_handler   = new Helper\WkAcct_Erp_Config_Handler();
			$this->data_handler     = new Helper\WkAcct_Erp_Data_Handler();
			$this->template_handler = new Admin\WkAcct_Erp_Admin_Templates();
			$this->config_temp = new Settings\WkAcct_Erp_Config_Template();
		}


		/**
		 * Register and enqueue scripts and styles
		 *
		 * @return void
		 */
		public function wkacct_erp_admin_scripts_handler() {
			$this->register_scripts();
			$this->register_styles();

			$this->enqueue_scripts();
			$this->enqueue_styles();
		}


		public function register_scripts() {

			$this->suffix  = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			$get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended

			// wp_register_script( $handle, $src, $deps, $ver, $in_footer );
			$vendor = WK_ACCT_ERP_ASSETS . '/vendor';
			$js     = WK_ACCT_ERP_ASSETS . '/js';
	
			// register vendors first
			wp_register_script( 'wkacct-erp-select2', $vendor . '/select2/select2.full.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-tiptip', $vendor . '/tiptip/jquery.tipTip.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-fullcalendar', $vendor . '/fullcalendar/fullcalendar' . $this->suffix . '.js', [ 'jquery', 'moment' ], $this->version, true );
			wp_register_script( 'wkacct-erp-datetimepicker', $vendor . '/jquery-ui/timepicker-addon/jquery-ui-timepicker-addon.min.js', [ 'jquery', 'moment' ], $this->version, true );
			wp_register_script( 'wkacct-erp-timepicker', $vendor . '/timepicker/jquery.timepicker.min.js', [ 'jquery', 'moment' ], $this->version, true );
			
			wp_register_script( 'wkacct-erp-trix-editor', $vendor . '/trix/trix.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-nprogress', $vendor . '/nprogress/nprogress.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-jvectormap', $vendor . '/jvectormap/jvectormap.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-jvectormap-world-mill', $vendor . '/jvectormap/jvectormap-world-mill.js', [ 'jquery' ], $this->version, true );
	
			// sweet alert
			wp_register_script( 'wkacct-erp-sweetalert', $vendor . '/sweetalert/sweetalert.min.js', [ 'jquery' ], $this->version, true );
	
			// Are you sure? JS
			wp_register_script( 'wkacct-erp-are-you-sure', $vendor . '/are-you-sure/jquery.are-you-sure.js', [ 'jquery' ], $this->version, true );
	
			// flot chart
			wp_register_script( 'wkacct-erp-flotchart', $vendor . '/flot/jquery.flot.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-time', $vendor . '/flot/jquery.flot.time.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-orerbars', $vendor . '/flot/jquery.flot.orderBars.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-pie', $vendor . '/flot/jquery.flot.pie.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-axislables', $vendor . '/flot/jquery.flot.axislabels.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-categories', $vendor . '/flot/jquery.flot.categories.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-tooltip', $vendor . '/flot/jquery.flot.tooltip.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-resize', $vendor . '/flot/jquery.flot.resize.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-valuelabel', $vendor . '/flot/jquery.flot.valuelabels.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-navigate', $vendor . '/flot/jquery.flot.navigate.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-selection', $vendor . '/flot/jquery.flot.selection.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-flotchart-stack', $vendor . '/flot/jquery.flot.stack.js', [ 'jquery' ], $this->version, true );
			// Enqueue Pikaday library
			wp_register_script('pikaday', 'https://cdn.jsdelivr.net/npm/pikaday/pikaday.js', [ 'jquery' ], '1.8.0', true);
			// Chart js library
			wp_register_script( 'wkacct-erp-chartjs', $vendor . '/chartjs/chart.min.js', [ 'jquery' ], $this->version, true );
	
			// core js files
			wp_enqueue_script( 'wkacct-erp-admin', $js . '/wkacct-erp-admin.js', array( 'wkacct-erp-select2', 'jquery', 'jquery-blockui', 'pikaday', 'wkacct-erp-chartjs' ), $this->version, true );
			// tether.js
			wp_register_script( 'wkacct-erp-tether-main', $vendor . '/tether/tether.min.js', [ 'jquery' ], $this->version, true );
			wp_register_script( 'wkacct-erp-tether-drop', $vendor . '/tether/drop.min.js', [ 'jquery' ], $this->version, true );
	
			// clipboard.js
			wp_register_script( 'wkacct-erp-clipboard', $vendor . '/clipboard/clipboard.min.js', [ 'jquery' ], $this->version, true );
	
			// toastr.js
			wp_register_script( 'wkacct-erp-toastr', $vendor . '/toastr/toastr.min.js', [], $this->version, true );
	
			// date range picker
			wp_register_script( 'wkacct-erp-daterangepicker', $vendor . '/daterangepicker/daterangepicker.min.js', [ 'jquery' ], $this->version, true );

			if( isset($get_data['page'] ) && 'wkacct-erp-config' === $get_data['page'] ) {
				wp_register_script( 'wkacct-erp-config', $js . '/wkacct-erp-config.js', array( 'wkacct-erp-select2', 'jquery', 'jquery-blockui' ), $this->version, true );
			}
		}
	
		/**
		 * Register all the styles
		 *
		 * @return void
		 */
		public function register_styles() {
			$get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended

			// wp_register_script( $handle, $src, $deps, $ver, $in_footer );
			$vendor = WK_ACCT_ERP_ASSETS . '/vendor';
			$css    = WK_ACCT_ERP_ASSETS . '/css';
	
			wp_register_style( 'wkacct-erp-fontawesome', $vendor . '/fontawesome/font-awesome.min.css', false, $this->version );
			wp_register_style( 'wkacct-erp-select2', $vendor . '/select2/select2.min.css', false, $this->version );
			wp_register_style( 'wkacct-erp-tiptip', $vendor . '/tiptip/tipTip.css', false, $this->version );
			wp_register_style( 'wkacct-erp-fullcalendar', $vendor . '/fullcalendar/fullcalendar' . $this->suffix . '.css', false, $this->version );
			wp_register_style( 'wkacct-erp-datetimepicker', $vendor . '/jquery-ui/timepicker-addon/jquery-ui-timepicker-addon.min.css', false, $this->version );
			wp_register_style( 'wkacct-erp-timepicker', $vendor . '/timepicker/jquery.timepicker.css', false, $this->version );
			wp_register_style( 'wkacct-erp-trix-editor', $vendor . '/trix/trix.css', false, $this->version );
			wp_register_style( 'wkacct-erp-flotchart-valuelabel-css', $vendor . '/flot/plot.css', false, $this->version );
			wp_register_style( 'wkacct-erp-nprogress', $vendor . '/nprogress/nprogress.css', false, $this->version );
			wp_register_style( 'wkacct-erp-jvectormap', $vendor . '/jvectormap/jvectormap.css', false, $this->version );
			
			// jquery UI
			wp_register_style( 'jquery-ui', $vendor . '/jquery-ui/jquery-ui-1.9.1.custom.css' );
	
			// sweet alert
			wp_register_style( 'wkacct-erp-sweetalert', $vendor . '/sweetalert/sweetalert.css', false, $this->version );
	
			// tether drop theme
			wp_register_style( 'wkacct-erp-tether-drop-theme', $vendor . '/tether/drop-theme.min.css', false, $this->version );
	
			// toastr.js
			wp_register_style( 'wkacct-erp-toastr', $vendor . '/toastr/toastr.min.css', false, $this->version );
	
			// core css files
			wp_register_style( 'wkacct-erp-styles', $css . '/wkacct-erp.css', [ 'wkacct-erp-sweetalert' ], $this->version );

			wp_register_style( 'wkacct-erp-admin', $css . '/wkacct-erp-admin.css', [ 'wkacct-erp-sweetalert' ], $this->version );

			wp_register_style( 'wkacct-erp-setting', $css . '/wkacct-erp-setting.css', [ 'wkacct-erp-sweetalert' ], $this->version );

			wp_register_style( 'wkacct-erp-nav', $css . '/wkacct-erp-nav.css', false, $this->version );

			if( isset($get_data['page'] ) && 'wkacct-erp-config' === $get_data['page'] ) {
				// custom menu design
				wp_register_style( 'wkacct-erp-custom-styles', $css . '/wkacct-erp-custom.css', false, $this->version );
			}
	
			// date range picker
			wp_register_style( 'wkacct-erp-daterangepicker', $vendor . '/daterangepicker/daterangepicker.min.css', false, $this->version );

		}



		/**
		 * Enqueue the scripts
		 *
		 * @return void
		 */
		public function enqueue_scripts() {
			$js     = WK_ACCT_ERP_ASSETS . '/js';
			$screen      = get_current_screen();
			$screen_base = isset( $screen->base ) ? $screen->base : false;
			$hook        = str_replace( sanitize_title( __( 'HR Management', 'erp' ) ), 'hr-management', $screen_base );
			wp_enqueue_script('jquery-ui-datepicker');
			wp_enqueue_script('wkacct-erp-daterangepicker');
			wp_enqueue_script( 'wkacct-erp-trix-editor' );
			wp_enqueue_script( 'wkacct-erp-select2' );
			wp_enqueue_script( 'wkacct-erp-popup' );
			wp_enqueue_script( 'wkacct-erp-chartjs' );
			wp_enqueue_script( 'pikaday' );

			wp_enqueue_script( 'wkacct-erp-script' );
			wp_enqueue_script( 'wkacct-erp-config' );
			wp_enqueue_script( 'wkacct-erp-are-you-sure' );
			wp_enqueue_media();

			$translated_strings = array(
				'uploadTitle'   => esc_html__( 'Upload Shipping Label', 'wk-acct-erp' ),
				'uploadBtnText' => esc_html__( 'Select', 'wk-acct-erp' ),
			);
			wp_localize_script(
				'wkacct-erp-config',
				'WkacctErp',
				array(
					'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
					'nonce'       => wp_create_nonce( 'wkacct_erp_ajax_nonce' ),
					'strings'     => $translated_strings,
				)
			);

			wp_localize_script( 'wkacct-erp-admin', 'WkacctErp', [
				'nonce'           => wp_create_nonce( 'wkacct-erp-nonce' ),
				'set_logo'        => __( 'Set company logo', 'wk-acct-erp' ),
				'upload_logo'     => __( 'Upload company logo', 'wk-acct-erp' ),
				'remove_logo'     => __( 'Remove company logo', 'wk-acct-erp' ),
				'update_location' => __( 'Update Location', 'wk-acct-erp' ),
				'create'          => __( 'Create', 'wk-acct-erp' ),
				'update'          => __( 'Update', 'wk-acct-erp' ),
				'formUnsavedMsg'  => __( 'You didn\'t save your changes!', 'wk-acct-erp' ),
				'confirmMsg'      => __( 'Are you sure?', 'wk-acct-erp' ),
				'ajaxurl'         => admin_url( 'admin-ajax.php' ),
				'plupload'        => [
					'url'              => admin_url( 'admin-ajax.php' ) . '?nonce=' . wp_create_nonce( 'wkacct_erp_featured_img' ),
					'filters'          => [ [ 'title' => __( 'Allowed Files', 'wk-acct-erp' ), 'extensions' => '*' ] ],
					'multipart'        => true,
					'urlstream_upload' => true,
				],
			] );
			

			// Optionally, include a theme for Pikaday
			wp_enqueue_style('pikaday-theme', 'https://cdn.jsdelivr.net/npm/pikaday/css/pikaday.css');
			
			wp_enqueue_script( 'wkacct-erp-menu', $js . '/wkacct-erp-menu.js', [], date( 'Ymd' ), true );

		}

		/**
		 * Enqueue the stylesheet
		 *
		 * @return void
		 */
		public function enqueue_styles() {
			wp_enqueue_style( 'wkacct-erp-fontawesome' );
			wp_enqueue_style( 'wkacct-erp-select2' );
			wp_enqueue_style( 'jquery-ui' );
			wp_enqueue_style( 'wkacct-erp-trix-editor' );
			
			wp_enqueue_style( 'wkacct-erp-styles' );
			wp_enqueue_style( 'wkacct-erp-setting' );
			wp_enqueue_style( 'wkacct-erp-admin' );
			wp_enqueue_style( 'wkacct-erp-nav' );


			$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';

			if ( ! empty( $page ) && 'wkacct-erp-config' === $page ) {
				wp_enqueue_style( 'wkacct-erp-custom-styles' );
			}
		}




		public function wkacct_erp_admin_menu() {
			$capability = apply_filters( 'wkacct_erp_menu_capability', 'wk_acct_erp_manager' );
			$menu_icon_src = 'dashicons-welcome-widgets-menus';
			$menu_icon     = apply_filters( 'wk_erp_addon_top_menu_icon', $menu_icon_src );

			$project_menu       = get_option( 'wkwp_erp_addon_settings_page_title', '' );
		    $project_slug       = title_slugify($project_menu );

			add_menu_page( __( 'WP Accounts', 'wk-acct-erp' ), __( 'WP Accounts', 'wk-acct-erp' ), $capability, 'wkacct-erp', array( $this, 'wkacct_erp_dashboard_page' ), $menu_icon, 5 );

			$dashboard = add_submenu_page( 'wkacct-erp', __( 'Dashboard', 'wk-acct-erp' ), __( 'Dashboard', 'wk-acct-erp' ), $capability, 'wkacct-erp', array( $this, 'wkacct_erp_dashboard_page' ) );

			if( !empty($project_slug)) {
				add_submenu_page( 'wkacct-erp',$project_menu , $project_menu, $capability, 'wkacct-erp-'.$project_slug, [ $this, 'wkacct_erp_manage_project' ] );
				wkacct_erp_add_menu_header( $project_slug, $project_menu, '<svg id="Group_235" data-name="Group 235" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 239 341.4"><path id="Path_281" data-name="Path 281" d="M221.9,0H17.1C6.8,0,0,6.8,0,17.1V324.3c0,10.2,6.8,17.1,17.1,17.1H221.9c10.2,0,17.1-6.8,17.1-17.1V17.1C238.9,6.8,232.1,0,221.9,0ZM68.3,307.2H34.1V273.1H68.2v34.1Zm0-68.3H34.1V204.8H68.2v34.1Zm0-68.2H34.1V136.6H68.2v34.1Zm68.2,136.5H102.4V273.1h34.1Zm0-68.3H102.4V204.8h34.1Zm0-68.2H102.4V136.6h34.1Zm68.3,136.5H170.7V273.1h34.1v34.1Zm0-68.3H170.7V204.8h34.1v34.1Zm0-68.2H170.7V136.6h34.1v34.1Zm0-68.3H34.1V34.1H204.8v68.3Zm0,0" class="cls-1"></path></svg>' );
			}

			$accounting = add_submenu_page( 'wkacct-erp', __( 'Accounting', 'wk-acct-erp' ), __( 'Accounting', 'wk-acct-erp' ), $capability, 'wkacct-erp-accounting', array( $this, 'wkacct_erp_accounting_page' ) );

			$company = add_submenu_page( 'wkacct-erp', __( 'Company', 'wk-acct-erp' ), __( 'Company', 'wk-acct-erp' ), $capability, 'wkacct-erp-company', array( $this, 'wkacct_erp_company_page' ) );

			add_submenu_page( 'wkacct-erp', __( 'Settings', 'wk-acct-erp' ), __( 'Settings', 'wk-acct-erp' ), $capability, 'wkacct-erp-config', array( $this, 'wkacct_erp_configuration_page' ) );
		}

		public function wkacct_erp_dashboard_page() {
			echo 'Dashboard';
		}

		public function wkacct_erp_accounting_page() {
			echo 'Accounting';
		}



		public function wkacct_erp_manage_project(){
			$capability = apply_filters( 'wkacct_erp_menu_capability', 'wk_acct_erp_manager' );
			$project_menu       = get_option( 'wkwp_erp_addon_settings_page_title', '' );
		    $project_slug       = title_slugify($project_menu );
			wkacct_erp_add_menu(
				$project_slug,
				[
					'title'      => $project_menu,
					'capability' => $capability,
					'slug'       => $project_slug,
					'callback'   => [ $this, 'wkacct_erp_event_event_page' ],
					'position'   => 1,
				]
			);

			wkacct_erp_add_menu(
				$project_slug,
				[
					'title'      => __( 'Transactions', 'wkwp_erp_addon' ),
					'capability' => $capability,
					'slug'       => 'transactions',
					'callback'   => [ $this, 'wkacct_erp_event_transaction_page' ],
					'position'   => 5,
				]
			);

			wkacct_erp_add_submenu(
				$project_slug,
				'transactions',
				[
					'title'      => __( 'Sales', 'wkwp_erp_addon' ),
					'capability' => $capability,
					'slug'       => 'sales',
					'callback'   => [ $this, 'wkacct_erp_event_sales_page' ],
					'position'   => 5,
				]
			);
			wkacct_erp_add_submenu(
				$project_slug,
				'transactions',
				[
					'title'      => __( 'Purchases', 'wkwp_erp_addon' ),
					'capability' => $capability,
					'slug'       => 'purchases',
					'callback'   => [ $this, 'wkacct_erp_event_purchases_page' ],
					'position'   => 10,
				]
			);

			wkacct_erp_add_menu(
				$project_slug,
				[
					'title'      => __( 'Product', 'wkwp_erp_addon' ),
					'capability' => $capability,
					'slug'       => 'products',
					'callback'   => [ $this, 'wkacct_erp_event_product_page' ],
					'position'   => 5,
				]
			);


			$component = $project_slug;
			$menu      = wkacct_erp_menu();
			
			$menu      = $menu[$component];

			$section = isset( $_GET['section'] ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : $project_slug;
			$section = isset( $menu[ $section ] ) ? $section : $project_slug;
			$sub     = isset( $_GET['sub-section'] ) ? sanitize_text_field( wp_unslash( $_GET['sub-section'] ) ) : false;
			$sub     = ! $sub || empty( $menu[ $section ]['submenu'][ $sub ] ) ? false : $sub;

			$callback = $menu[$section]['callback'];

			if ( $sub ) {
				$callback = $menu[$section]['submenu'][$sub]['callback'];
			}
			?>
			<div class="wrap wkacct-erp-wrap">
				<div id="wkacct-erp-event">
					<?php 
						wkacct_erp_render_menu( $component );
						if ( is_callable( $callback ) ) {
							call_user_func( $callback );
						}
					?>
				</div>
			</div>
			<?php
		}



		public function wkacct_erp_company_page() {
			echo 'Company';
		}

		public function wkacct_erp_configuration_page() {
			$this->template_handler->wkacct_erp_configuration_template();
		}

		/**
		 * Display Html Content Helper Method To Allowed Html Element Properties
		 *
		 * @param array $element element Existed .
		 *
		 * @return mixed
		 */
		public function wkacct_erp_display_html_content_with_escape( $element ) {
			$allowed_tags = array();
			if ( $element ) {
				foreach ( $element as $key => $value ) {
					if ( 'input' === $value ) {
						$allowed_tags['input'] = array(
							'type'               => true,
							'value'              => true,
							'name'               => true,
							'class'              => true,
							'id'                 => true,
							'multiple'           => true,
							'min'                => true,
							'max'                => true,
							'placeholder'        => true,
							'step'               => true,
							'size'               => true,
							'checked'            => true,
							'data-default-color' => true,
						);
					}
					if ( 'select' === $value ) {
						$allowed_tags['select'] = array(
							'class' => true,
							'id'    => true,
							'name'  => true,
						);
					}
					if ( 'option' === $value ) {
						$allowed_tags['option'] = array(
							'class'    => true,
							'id'       => true,
							'value'    => true,
							'selected' => true,
						);
					}
					if ( 'textarea' === $value ) {
						$allowed_tags['textarea'] = array(
							'class' => true,
							'id'    => true,
							'name'  => true,
							'row'   => true,
							'col'   => true,
						);
					}
					if ( 'fieldset' === $value ) {
						$allowed_tags['fieldset'] = array();
					}

					if ( 'label' === $value ) {
						$allowed_tags['label'] = array(
							'for'   => true,
							'class' => true,
							'id'    => true,
						);
					}
					if ( 'h2' === $value ) {
						$allowed_tags['h2'] = array(
							'class' => true,
							'id'    => true,
						);
					}
					if ( 'a' === $value ) {
						$allowed_tags['a'] = array(
							'href'  => true,
							'class' => true,
							'id'    => true,
						);
					}
					if ( 'span' === $value ) {
						$allowed_tags['span'] = array(
							'class' => true,
							'id'    => true,
						);
					}
					if ( 'p' === $value ) {
						$allowed_tags['p'] = array(
							'class' => true,
							'id'    => true,
						);
					}
					if ( 'br' === $value ) {
						$allowed_tags['br'] = array();
					}
					if ( 'hr' === $value ) {
						$allowed_tags['hr'] = array();
					}
				}
			}

			return $allowed_tags;
		}

		/**
		 * Configuration menu
		 *
		 * @return void
		 */


		public function wkacct_erp_config_content($submenu) {
			$this->template_handler->wkacct_erp_config_page_template();
		}

		
		public function wkacct_erp_config_project_content($general_submenu_name) {
			$this->template_handler->wkacct_erp_config_projects_content($general_submenu_name);
		}

		public function wkacct_erp_config_payment_project_content($general_submenu_name) {
			$this->template_handler->wkacct_erp_config_payment_content($general_submenu_name);
		}

		public function wkacct_erp_config_hmrc_setting_general_content($general_submenu_name) {
			$this->template_handler->wkacct_erp_config_hmrc_content($general_submenu_name);
		}

		public function wkacct_erp_config_vat_setting_general_content($general_submenu_name) {
			$this->template_handler->wkacct_erp_config_vat_setting_content($general_submenu_name);
		}

		// AutoCredit Control
		public function wkacct_erp_config_auto_credit_control_content($general_submenu_name){
			$this->config_temp->wkacct_erp_config_auto_credit_control_settings($general_submenu_name);
		}

		// pdf settings

		public function wkacct_erp_config_pdf_theme_control_content($general_submenu_name){
			$this->config_temp->wkacct_erp_config_pdf_theme_settings($general_submenu_name);
		}

		// Paypal Import

		public function wkacct_erp_config_paypal_import_content($general_submenu_name){
			$this->config_temp->wkacct_erp_config_paypal_import_settings($general_submenu_name);
		}


		public function wkacct_erp_event_event_page(){
			$this->template_handler->wkacct_erp_event_page_template();
		}

		public function wkacct_erp_event_product_page(){
			$this->template_handler->wkacct_erp_event_product_page_template();
		}

		public function wkacct_erp_event_transaction_page(){
			$this->template_handler->wkacct_erp_event_transaction_page_template();
		}

	}

}
