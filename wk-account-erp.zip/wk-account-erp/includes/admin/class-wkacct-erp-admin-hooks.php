<?php
/**
 * Admin Hooks.
 *
 * @package WkAcctErp\Includes\Admin
 * @since   1.0.0
 */
namespace WkAcctErp\Includes\Admin;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Includes\Admin\Ajax;


if ( ! class_exists( 'WkAcct_Erp_Admin_Hooks' ) ) {

	/**
	 * Admin hooks class.
	 */
	class WkAcct_Erp_Admin_Hooks {

		/**
		 * Admin Hook constructor
		 */
		public function __construct() {
			new Ajax\WkAcct_Erp_Ajax_Hooks();
			/**
			 * Admin Function Object
			 */
			$function_handler = new WkAcct_Erp_Admin_Functions();

			add_action( 'admin_menu', array( $function_handler, 'wkacct_erp_admin_menu' ) );

			add_action( 'admin_enqueue_scripts', array( $function_handler, 'wkacct_erp_admin_scripts_handler' ) );

			add_filter( 'wkacct_erp_display_html_content_with_escape', array( $function_handler, 'wkacct_erp_display_html_content_with_escape' ) );

			add_action( 'wkacct-erp-config_content', array($function_handler, 'wkacct_erp_config_content') );

			add_action( 'wkacct-erp-config_general_content', array($function_handler, 'wkacct_erp_config_project_content') );

			add_action( 'wkacct-erp-config_payment_general_content', array($function_handler, 'wkacct_erp_config_payment_project_content') );

			add_action( 'wkacct-erp-config_hmrc_setting_general_content', array($function_handler, 'wkacct_erp_config_hmrc_setting_general_content') );

			add_action( 'wkacct-erp-config_vat_setting_general_content', array($function_handler, 'wkacct_erp_config_vat_setting_general_content') );

			add_action( 'wkacct-erp-config_auto_credit_control_content', array($function_handler, 'wkacct_erp_config_auto_credit_control_content') );

			add_action( 'wkacct-erp-config_pdf_theme_control_content', array($function_handler, 'wkacct_erp_config_pdf_theme_control_content') );
			
			add_action( 'wkacct-erp-config_paypal_import_control_content', array($function_handler, 'wkacct_erp_config_paypal_import_content') );
			

		}

	}

}
