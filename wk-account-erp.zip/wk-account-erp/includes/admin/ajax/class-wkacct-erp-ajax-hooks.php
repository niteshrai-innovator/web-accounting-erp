<?php
/**
 * Ajax Hooks.
 *
 * @package WkAcctErp\Includes\Admin|Ajax
 * @since   1.0.0
 */
namespace WkAcctErp\Includes\Admin\Ajax;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WkAcct_Erp_Ajax_Hooks' ) ) {

	/**
	 * Admin hooks class.
	 */
	class WkAcct_Erp_Ajax_Hooks {

		/**
		 * Admin Hook constructor
		 */
		public function __construct() {

            /**
			 * Admin Function Object
			 */
			$function_handler = new WkAcct_Erp_Ajax_Functions();

            // enable chat notification.
			add_action( 'wp_ajax_nopriv_wkacct_general_settion_action', array( $function_handler, 'wkacct_general_settion_action' ) );
			add_action( 'wp_ajax_wkacct_general_settion_action', array( $function_handler, 'wkacct_general_settion_action' ) );

        }
    }
}