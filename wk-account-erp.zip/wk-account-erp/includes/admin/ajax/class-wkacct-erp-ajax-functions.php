<?php
/**
 * Ajax Hooks.
 *
 * @package WkAcctErp\Includes\Admin|Ajax
 * @since   1.0.0
 */
namespace WkAcctErp\Includes\Admin\Ajax;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WkAcct_Erp_Ajax_Functions' ) ) {

	/**
	 * Admin hooks class.
	 */
	class WkAcct_Erp_Ajax_Functions {

		/**
		 * Admin Hook constructor
		 */
		public function __construct() {

        }

        public function wkacct_general_settion_action(){
            $post_data = wp_unslash( $_POST );
           	wkacct_erp()->api->wkacct_erp_save_project_setting($post_data);
        }
    }
}