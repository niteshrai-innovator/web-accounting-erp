<?php

function title_slugify($text, string $divider = '-')
{
  // replace non letter or digits by divider
  $text = preg_replace('~[^\pL\d]+~u', $divider, $text);

  // transliterate
  $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

  // remove unwanted characters
  $text = preg_replace('~[^-\w]+~', '', $text);

  // trim
  $text = trim($text, $divider);

  // remove duplicate divider
  $text = preg_replace('~-+~', $divider, $text);

  // lowercase
  $text = strtolower($text);

  if (empty($text)) {
    return 'n-a';
  }

  return $text;
}

function generate_random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('A', 'Z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
}


/**
 * Get ERP Menu array
 *
 * @since 1.4.0
 *
 * @return array $menu
 */
function wkacct_erp_get_menu_headers() {
  $menu = [];

  return apply_filters( 'wkacct_erp_menu_headers', $menu );
}


/**
 * Add Header part of Component
 *
 * @param $component
 * @param $title
 * @param string $icon
 */
function wkacct_erp_add_menu_header( $component, $title, $icon = '' ) {
  add_filter( 'wkacct_erp_menu_headers', function ( $menu ) use ( $component, $title, $icon ) {
      $menu[ $component ] = [
    'title' => $title,
    'icon' => $icon,
  ];

      return $menu;
  } );
}

/**
 * Add a menu item into ERP Menu
 *
 * @since 1.4.0
 *
 * @param string $component Name of Component to add menu
 * @param array  $args
 *
 * @return void
 */
function wkacct_erp_add_menu( $component, $args ) {
  add_filter( 'wkacct_erp_menu', function ( $menu ) use ( $component, $args ) {
      $menu[ $component ][ $args['slug'] ] = $args;

      return $menu;
  } );
}

/**
 * Adds a submenu under a Menu item
 *
 * @since 1.4.0
 *
 * @param string $component Name of Component to add menu
 * @param string $parent    Slug of Parent menu item
 * @param array  $args
 *
 * @return void
 */
function wkacct_erp_add_submenu( $component, $parent, $args ) {
  add_filter( 'wkacct_erp_menu', function ( $menu ) use ( $component, $parent, $args ) {
      if ( ! isset( $menu[ $component ][ $parent ] ) ) {
          return $menu;
      }
      $args['parent'] = $parent;
      $menu[ $component ][ $parent ]['submenu'][ $args['slug'] ] = $args;

      return $menu;
  } );
}


/**
 * Render header part of erp menu
 *
 * @param $component
 *
 * @return string
 */
function wkacct_erp_render_menu_header( $component ) {
  $headers = wkacct_erp_get_menu_headers();

  if ( empty( $headers[ $component ] ) ) {
      return '';
  }

  $html = sprintf( '<div class="erp-page-header">
                      <div class="module-icon">
                          %s
                      </div>
                      <p class="page-title">%s</p>
                  </div>',
                  $headers[ $component ]['icon'],
                  $headers[ $component ]['title'] );

  return $html;
}

/**
 * Get ERP Menu array
 *
 * @since 1.4.0
 *
 * @return array $menu
 */
function wkacct_erp_menu() {
  $menu = [];

  return apply_filters( 'wkacct_erp_menu', $menu );
}


/**
 * Render A menu for given component
 *
 * @since 1.4.0
 *
 * @param string $component slug of Component to render
 *
 * @return bool
 */
function wkacct_erp_render_menu( $component ) {
  $menu = wkacct_erp_menu();

  if ( ! isset( $menu[ $component ] ) ) {
      return false;
  }
  //check current tab
  $tab = isset( $_GET['section'] ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : 'dashboard';

  ?>
  <div class='erp-nav-container erp-hide-print'>
      <?php
      echo wkacct_erp_render_menu_header( $component );
      echo wp_kses_post( wkacct_erp_build_menu( $menu[ $component ], $tab, $component ) );
      ?>
  </div>
  <?php
}

function wkacct_erp_comparison($a, $b) {
    if ($a > $b) {
        return 1; // A positive integer
    } elseif ($a < $b) {
        return -1; // A negative integer
    } else {
        return 0; // Zero
    }
}

/**
 * Build html for ERP menu
 *
 * @since 1.4.0
 *
 * @param $items
 * @param $active
 * @param $component main component slug
 * @param bool $dropdown
 *
 * @return string
 */
function wkacct_erp_build_menu( $items, $active, $component, $dropdown = false ) {

  //check capability
  $items = array_filter( $items, function ( $item ) {
      if ( ! isset( $item['capability'] ) ) {
          return false;
      }

      return current_user_can( $item['capability'] );
  } );

  uasort( $items, 'wkacct_erp_comparison');
  //sort items for position
  // uasort( $items, function ( $a, $b ) {
  //     return $a['position'] > $b['position'];
  // } );

  $html = '<ul class="erp-nav -primary erp-hide-print">';

  if ( $dropdown ) {
      $html = '<ul class="erp-nav-dropdown">';
  }

  foreach ( $items as $item ) {
      $link = add_query_arg( [
    'page' => 'wkacct-erp-' . $component,
    'section' => $item['slug'],
  ], admin_url( 'admin.php' ) );

      $class = $active === $item['slug'] ? 'active ' : '';
      $pro_popup = '';
      if ( ! empty( $item['pro_popup'] ) ) {
          $pro_popup = '<span class="pro-popup">Pro</span>';
          $class .= ' pro-popup-main ';
      }

      if ( $dropdown ) {
          $link = add_query_arg( [ 'page' => 'wkacct-erp-' . $component, 'section' => $item['parent'], 'sub-section' => $item['slug'] ], admin_url( 'admin.php' ) );
          $class .= ( ! empty( $_GET['sub-section'] ) && $_GET['sub-section'] === $item['slug'] ) ? 'active ' : '';
      }

      if ( ! empty( $item['direct_link'] ) ) {
          $link = $item['direct_link'];
      }

      $submenu = '';

      if ( isset( $item['submenu'] ) ) {
          $class .= 'dropdown-nav';
          $submenu .= wkacct_erp_build_menu( $item['submenu'], $active, $component, true );
      }

      $html .= sprintf( '<li class="%s"><a href="%s">%s</a>%s%s</li>', $class, $link, $item['title'], $submenu, $pro_popup );
  }

  $html .= '</ul>';

  return $html;
}