<?php
/**
 * Config Handler
 *
 * @package WkAcctErp\Helper
 * @since 1.0.0
 */

namespace WkAcctErp\Helper;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WkAcct_Erp_Config_Handler' ) ) {

	/**
	 * Config Handler class.
	 */
	class WkAcct_Erp_Config_Handler {

		/**
		 * Settings sections array
		 *
		 * @var array
		 */
		public $settings_sections = array();

		/**
		 * Settings fields array
		 *
		 * @var array
		 */
		public $settings_fields = array();

		/**
		 * Set settings sections
		 *
		 * @param array $sections setting sections array.
		 * @return array
		 */
		public function wkacct_erp_set_config_sections( $sections ) {
			$this->settings_sections = $sections;
			return $this->settings_sections;
		}

		/**
		 * Set settings fields
		 *
		 * @param array $fields settings fields array.
		 * @return array
		 */
		public function wkacct_erp_set_config_fields( $fields ) {
			$this->settings_fields = $fields;
			return $this->settings_fields;
		}

		/**
		 * Initialize and registers the settings sections and fields to WordPress
		 */
		public function wkacct_erp_init_config_settings() {
			// register settings sections.
			foreach ( $this->settings_sections as $section ) {
				if ( false === get_option( $section['id'] ) ) {//PHPCS:ignore
					add_option( $section['id'] );
				}

				if ( isset( $section['desc'] ) && ! empty( $section['desc'] ) ) {
					$section['desc'] = '<div class="inside">' . $section['desc'] . '</div>';
					$callback        = function() use ( $section ) {
						echo wp_kses_post( str_replace( '"', '\"', $section['desc'] ) );
					};
				} elseif ( isset( $section['callback'] ) ) {
					$callback = $section['callback'];
				} else {
					$callback = null;
				}

				add_settings_section( $section['id'], $section['title'], $callback, $section['id'] );
			}
			// register settings fields.
			foreach ( $this->settings_fields as $section => $field ) {
				foreach ( $field as $option ) {

					$name     = $option['name'];
					$type     = isset( $option['type'] ) ? $option['type'] : 'text';
					$label    = isset( $option['label'] ) ? $option['label'] : '';
					$callback = isset( $option['callback'] ) ? $option['callback'] : array( $this, 'wkacct_erp_callback_' . $type );
					
					$args = array(
						'id'                => $name,
						'class'             => isset( $option['class'] ) ? $option['class'] : $name,
						'label_for'         => "{$section}[{$name}]",
						'desc'              => isset( $option['desc'] ) ? $option['desc'] : '',
						'name'              => $label,
						'section'           => $section,
						'size'              => isset( $option['size'] ) ? $option['size'] : null,
						'options'           => isset( $option['options'] ) ? $option['options'] : '',
						'std'               => isset( $option['default'] ) ? $option['default'] : '',
						'sanitize_callback' => isset( $option['sanitize_callback'] ) ? $option['sanitize_callback'] : '',
						'type'              => $type,
						'placeholder'       => isset( $option['placeholder'] ) ? $option['placeholder'] : '',
						'min'               => isset( $option['min'] ) ? $option['min'] : '',
						'max'               => isset( $option['max'] ) ? $option['max'] : '',
						'step'              => isset( $option['step'] ) ? $option['step'] : '',
					);

					add_settings_field( "{$section}[{$name}]", $label, $callback, $section, $section, $args );
				}
			}

			// creates our settings in the options table.
			foreach ( $this->settings_sections as $section ) {
				register_setting( $section['id'], $section['id'], array( $this, 'wkacct_erp_sanitize_options' ) );
			}
		}

		/**
		 * Sanitize callback for Settings API
		 *
		 * @param array $options .
		 * @return array
		 */
		public function wkacct_erp_sanitize_options( $options ) {

			if ( ! $options ) {
				return $options;
			}

			foreach ( $options as $option_slug => $option_value ) {
				$sanitize_callback = $this->wkacct_erp_get_sanitize_callback( $option_slug );

				// If callback is set, call it.
				if ( $sanitize_callback ) {
					$options[ $option_slug ] = call_user_func( $sanitize_callback, $option_value );
					continue;
				}
			}

			return $options;
		}

		/**
		 * Get sanitization callback for given option slug
		 *
		 * @param string $slug option slug.
		 *
		 * @return mixed string or bool false
		 */
		public function wkacct_erp_get_sanitize_callback( $slug = '' ) {
			if ( empty( $slug ) ) {
				return false;
			}

			// Iterate over registered fields and see if we can find proper callback.
			foreach ( $this->settings_fields as $section => $options ) {
				foreach ( $options as $option ) {
					if ( $slug !== $option['name'] ) {
						continue;
					}

					// Return the callback name.
					return isset( $option['sanitize_callback'] ) && is_callable( $option['sanitize_callback'] ) ? $option['sanitize_callback'] : false;
				}
			}

			return false;
		}

		/**
		 * Get field description for display
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_get_field_description( $args ) {
			if ( ! empty( $args['desc'] ) ) {
				$desc = sprintf( '<p class="description">%s</p>', $args['desc'] );
			} else {
				$desc = '';
			}

			return $desc;
		}

		/**
		 * Get the value of a settings field
		 *
		 * @param string $option  settings field name.
		 * @param string $section the section name this field belongs to.
		 * @param string $default default text if it's not found.
		 * @return string
		 */
		public function wkacct_erp_get_option( $option, $section, $default = '' ) {

			$options = get_option( $section );

			if ( isset( $options[ $option ] ) ) {
				return $options[ $option ];
			}

			return $default;
		}

		/**
		 * Displays a text field for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_text( $args ) {
			$value       = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size        = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';
			$type        = isset( $args['type'] ) ? $args['type'] : 'text';
			$placeholder = empty( $args['placeholder'] ) ? '' : ' placeholder="' . $args['placeholder'] . '"';

			$html  = sprintf( '<input type="%1$s" class="%2$s-text" id="%3$s[%4$s]" name="%3$s[%4$s]" value="%5$s"%6$s/>', $type, $size, $args['section'], $args['id'], $value, $placeholder );
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p' ) );
			
			echo wp_kses(
				$html,
				$allowed_tags
			);
		}

		/**
		 * Displays a url field for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_url( $args ) {
			$this->wkacct_erp_callback_text( $args );
		}

		/**
		 * Displays a number field for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_number( $args ) {
			$value       = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size        = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';
			$type        = isset( $args['type'] ) ? $args['type'] : 'number';
			$placeholder = empty( $args['placeholder'] ) ? '' : ' placeholder="' . $args['placeholder'] . '"';
			$min         = ( '' === $args['min'] ) ? '' : ' min="' . $args['min'] . '"';
			$max         = ( '' === $args['max'] ) ? '' : ' max="' . $args['max'] . '"';
			$step        = ( '' === $args['step'] ) ? '' : ' step="' . $args['step'] . '"';

			$html  = sprintf( '<input type="%1$s" class="%2$s-number" id="%3$s[%4$s]" name="%3$s[%4$s]" value="%5$s"%6$s%7$s%8$s%9$s/>', $type, $size, $args['section'], $args['id'], $value, $placeholder, $min, $max, $step );
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a checkbox for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_checkbox( $args ) {

			$value = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );

			$html  = '<fieldset>';
			$html .= sprintf( '<label for="wkacct-erp-%1$s[%2$s]">', $args['section'], $args['id'] );
			$html .= sprintf( '<input type="hidden" name="%1$s[%2$s]" value="off" />', $args['section'], $args['id'] );
			$html .= sprintf( '<input type="checkbox" class="checkbox" id="wkacct-erp-%1$s[%2$s]" name="%1$s[%2$s]" value="on" %3$s />', $args['section'], $args['id'], checked( $value, 'on', false ) );
			$html .= sprintf( '%1$s</label>', $args['desc'] );
			$html .= '</fieldset>';

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p', 'fieldset', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a multi checkbox for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_multicheck( $args ) {

			$value = $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] );

			$html  = '<fieldset>';
			$html .= sprintf( '<input type="hidden" name="%1$s[%2$s]" value="" />', $args['section'], $args['id'] );
			foreach ( $args['options'] as $key => $label ) {
				$checked = ! empty( $value ) && in_array( $key, $value, true ) ? $key : 0;
				$html   .= sprintf( '<label for="wkacct-erp-%1$s[%2$s][%3$s]">', $args['section'], $args['id'], $key );
				$html   .= sprintf( '<input type="checkbox" class="checkbox" id="wkacct-erp-%1$s[%2$s][%3$s]" name="%1$s[%2$s][%3$s]" value="%3$s" %4$s />', $args['section'], $args['id'], $key, checked( $checked, $key, false ) );
				$html   .= sprintf( '%1$s</label><br>', $label );
			}

			$html .= $this->wkacct_erp_get_field_description( $args );
			$html .= '</fieldset>';

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p', 'fieldset', 'label', 'br' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a radio button for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_radio( $args ) {

			$value = $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] );
			$html  = '<fieldset>';

			foreach ( $args['options'] as $key => $label ) {
				$html .= sprintf( '<label for="wkacct-erp-%1$s[%2$s][%3$s]">', $args['section'], $args['id'], $key );
				$html .= sprintf( '<input type="radio" class="radio" id="wkacct-erp-%1$s[%2$s][%3$s]" name="%1$s[%2$s]" value="%3$s" %4$s />', $args['section'], $args['id'], $key, checked( $value, $key, false ) );
				$html .= sprintf( '%1$s</label><br>', $label );
			}

			$html .= $this->wkacct_erp_get_field_description( $args );
			$html .= '</fieldset>';

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p', 'fieldset', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a select box for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_select( $args ) {
			$value = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size  = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';
			$html  = sprintf( '<select class="%1$s" name="%2$s[%3$s]" id="%2$s[%3$s]">', $size, $args['section'], $args['id'] );

			foreach ( $args['options'] as $key => $label ) {
				$html .= sprintf( '<option value="%s"%s>%s</option>', $key, selected( $value, $key, false ), $label );
			}

			$html .= sprintf( '</select>' );
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'select', 'option', 'p', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a textarea for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_textarea( $args ) {

			$value       = esc_textarea( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size        = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';
			$placeholder = empty( $args['placeholder'] ) ? '' : ' placeholder="' . $args['placeholder'] . '"';

			$html  = sprintf( '<textarea rows="5" cols="55" class="%1$s-text" id="%2$s[%3$s]" name="%2$s[%3$s]"%4$s>%5$s</textarea>', $size, $args['section'], $args['id'], $placeholder, $value );
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'textarea', 'p', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a rich text textarea for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_wysiwyg( $args ) {

			$value = $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] );
			$size  = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : '500px';

			echo '<div style="max-width: ' . esc_attr( $size ) . ';">';

			$editor_settings = array(
				'teeny'         => true,
				'textarea_name' => $args['section'] . '[' . $args['id'] . ']',
				'textarea_rows' => 10,
			);

			if ( isset( $args['options'] ) && is_array( $args['options'] ) ) {
				$editor_settings = array_merge( $editor_settings, $args['options'] );
			}

			wp_editor( $value, $args['section'] . '-' . $args['id'], $editor_settings );

			echo '</div>';

			echo wp_kses_post( $this->wkacct_erp_get_field_description( $args ) );
		}

		/**
		 * Displays a file upload field for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_file( $args ) {

			$value = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size  = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';
			$id    = $args['section'] . '[' . $args['id'] . ']';
			$label = isset( $args['options']['button_label'] ) ? $args['options']['button_label'] : __( 'Choose File', 'wkwc_rma' );

			$html  = sprintf( '<input type="text" class="%1$s-text wkacct-erp-url" id="%2$s[%3$s]" name="%2$s[%3$s]" value="%4$s"/>', $size, $args['section'], $args['id'], $value );
			$html .= '<input type="button" class="button wkacct-erp-browse" value="' . $label . '" />';
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a password field for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_password( $args ) {

			$value = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size  = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';

			$html  = sprintf( '<input type="password" class="%1$s-text" id="%2$s[%3$s]" name="%2$s[%3$s]" value="%4$s"/>', $size, $args['section'], $args['id'], $value );
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

		/**
		 * Displays a color picker field for a settings field
		 *
		 * @param array $args settings field args.
		 */
		public function wkacct_erp_callback_color( $args ) {

			$value = esc_attr( $this->wkacct_erp_get_option( $args['id'], $args['section'], $args['std'] ) );
			$size  = isset( $args['size'] ) && ! is_null( $args['size'] ) ? $args['size'] : 'regular';

			$html  = sprintf( '<input type="text" class="%1$s-text wp-color-picker-field" id="%2$s[%3$s]" name="%2$s[%3$s]" value="%4$s" data-default-color="%5$s" />', $size, $args['section'], $args['id'], $value, $args['std'] );
			$html .= $this->wkacct_erp_get_field_description( $args );

			$allowed_tags = apply_filters( 'wkacct_erp_display_html_content_with_escape', array( 'input', 'p', 'label' ) );
			echo wp_kses( $html, $allowed_tags );
		}

	}

}
