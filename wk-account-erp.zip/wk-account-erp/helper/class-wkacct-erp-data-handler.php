<?php
/**
 * Data Handler
 *
 * @package WkAcctErp\Helper
 * @since 1.0.0
 */

namespace WkAcctErp\Helper;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WkAcct_Erp_Data_Handler' ) ) {

	/**
	 * Data Handler class.
	 */
	class WkAcct_Erp_Data_Handler {

		/**
		 * DB global variable
		 *
		 * @var Object
		 */
		protected $wpdb;

		/**
		 * Construct function
		 */
		public function __construct() {
			global $wpdb;
			$this->wpdb = $wpdb;
		}

		/**
		 * Warranty request status
		 *
		 * @param string $time .
		 *
		 * @return array|String
		 */
		public function wkacct_erp_time_option( $time = '' ) {

			$times = apply_filters(
				'wkacct_erp_time_option',
				array(
					'11am'        => __( '11am', 'wk-acct-erp' ),
					'2pm'    => __( '2pm', 'wk-acct-erp' ),
					'5pm' => __( '5pm', 'wk-acct-erp' ),
					'8pm'   => __( '8pm', 'wk-acct-erp' ),
				)
			);

			if ( ! empty( $time ) ) {
				return ! empty( $times[ $time ] ) ? $times[ $time ] : '';
			}

			return $times;
		}
	}
}
