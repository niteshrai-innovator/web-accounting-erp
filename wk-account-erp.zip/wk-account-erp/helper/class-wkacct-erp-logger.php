<?php
/**
 * This file handles Error Logs
 *
 * @package WkAcctErp\Helper\Dibs\Core
 * @version 1.0.0
 */

 namespace WkAcctErp\Helper;

/**
 * Dibs Logger Class
 */
class WkAcct_Erp_Logger {

	/**
	 * $logger
	 *
	 * @var string
	 */
	public static $logger;

	/**
	 * $logger file name
	 *
	 * @var string
	 */
	const LOG_FILENAME = 'wk-accounting-erp';

	/**
	 * Logs an event.
	 *
	 * @param string|array $data The data string|array.
	 */
	public static function log( $data ) {

		if ( ! class_exists( 'WC_Logger' ) ) {
			return;
		}
		
        $message = self::format_data( $data );

        if ( empty( self::$log ) ) {

            self::$logger = new \WC_Logger();

        }

        $log_entry = sprintf( '==== WC WP Accounts Log Start [%s] ====', gmdate( 'd/m/Y H:i:s' ) ) . "\n\n";

        $log_entry .= wp_json_encode( $message, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n\n";

        $log_entry .= '====WC WP Accounts Log End====' . "\n\n";

        self::$logger->add( self::LOG_FILENAME, $log_entry );
	}

	/**
	 * Formats the log data to prevent json error.
	 *
	 * @param string|array $data The data string|array.
	 *
	 * @return string|array
	 */
	public static function format_data( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		if ( isset( $data['request']['body'] ) ) {
			$request_body            = json_decode( $data['request']['body'], true );
			$data['request']['body'] = ( ! empty( $request_body ) ) ? $request_body : $data['request']['body'];
		}

		return $data;
	}

	/**
	 * Formats the log data to be logged.
	 *
	 * @param string $checkout_id The gateway Checkout ID.
	 * @param string $method The method.
	 * @param string $title The title for the log.
	 * @param array  $request_args The request args.
	 * @param string $request_url The request url.
	 * @param array  $response The response.
	 * @param string $code The status code.
	 * @return array
	 */
	public static function format_log( $checkout_id, $method, $title, $request_args, $request_url, $response, $code ) {
		return array(
			'id'             => $checkout_id,
			'type'           => $method,
			'title'          => $title,
			'request_url'    => $request_url,
			'request'        => $request_args,
			'response'       => array(
				'body' => $response['body'],
				'code' => $code,
			),
			'timestamp'      => gmdate( 'Y-m-d H:i:s' ), // phpcs:ignore WordPress.DateTime.RestrictedFunctions -- Date is not used for display.
			'plugin_version' => WK_ACCT_ERP_VERSION,
		);
	}
}
