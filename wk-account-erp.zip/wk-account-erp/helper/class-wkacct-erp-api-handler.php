<?php
/**
 * Dibs API Class file.
 *
 * @package WkAcctErp\Helper
 * @version 1.0.0
 */

namespace WkAcctErp\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WkAcctErp\Api\Request\Post;
use WkAcctErp\Api\Request\Get;

/**
 * WkAcct_Erp_Api_Handler class. Class
 */
class WkAcct_Erp_Api_Handler {

	/**
	 * Save Project Setting
	 *
	 * @return array|mixed
	 */
	public function wkacct_erp_save_project_setting($post_data) {
		$request = new Post\WkAcct_Erp_Request_Config(
			$post_data
		);

		$response = $request->request();

		return $this->wkacct_erp_check_for_api_error( $response );
	}

	/**
	 * Save Project Setting
	 *
	 * @return array|mixed
	 */
	public function wkacct_erp_get_project_setting() {
		$request = new Get\WkAcct_Erp_Request_Get_Config();

		$response = $request->request();

		return $this->wkacct_erp_check_for_api_error( $response );
	}


	/**
	 * Checks for WP Errors and returns either the response as array or a false.
	 *
	 * @param array|WP_Error $response The response from the request.
	 * @return mixed
	 */
	private function wkacct_erp_check_for_api_error( $response ) {
		if ( is_wp_error( $response ) && ! is_admin() ) {
			wkacct_erp()->wkacct_erp_error_print_notification( $response );
		}
		return $response;
	}
}
