<?php 
$menu_class = 'router-link-exact-active router-link-active';
?>
<div class="content-area">
    <h2 class="section-title">General Setting</h2>
    <div class="submenu-content">
        <div class="settings-submenu-navbar">
            <ul class="settings-sub-menu">
                <?php
                    $tabs_nonce = wp_create_nonce( 'wkacct_erp_general_tabs_nonce' );

                    foreach ( $general_tabs as $tname => $tab_data ) {
                        $general_tab_url  = admin_url( 'admin.php?page=' . esc_attr( 'wkacct-erp-config' ) );
                        $general_tab_url .= ( $tname === $general_submenu_name ) ? '' : '&general-tab=' . $tname;
                        $general_tab_url .= '&_wkacct_erp_general_nonce=' . $tabs_nonce;
                    ?>
                <li>
                <li class="<?php if( 'wkacct-erp-config_'.$tname === $general_submenu_page ){ echo esc_attr($menu_class);} ?>"><a href="<?php echo esc_url( $general_tab_url ); ?>"><span class="menu-name"><?php echo esc_html( $tab_data ); ?></span></a></li>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>
    <div class="template-content">
        <?php
        if(empty($running_tab)) {
            $general_submenu_page .= '_general';
        }
        // var_dump($general_submenu_page . '_content');
        do_action( $general_submenu_page . '_content', $general_submenu_name );
        ?>
    </div>
</div>