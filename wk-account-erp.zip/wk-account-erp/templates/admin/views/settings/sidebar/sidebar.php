<?php 
defined( 'ABSPATH' ) || exit;
?>
<div id="wk-erp-addon-settings">
    <div class="settings-area">
        <div class="settings-sidebar">
            <div class="settings-navbar">
                <h2>Settings</h2>
                <ul class="settings-menu">
                    <?php
                        $tabs_nonce = wp_create_nonce( 'wkacct_erp_sidebar_tabs_nonce' );
                        foreach ( $tabs as $name => $tab_data ) {
                            $tab_url  = admin_url( 'admin.php?page=' . esc_attr( $submenu_name ) );
                            $tab_url .= ( $name === $submenu_name ) ? '' : '&tab=' . $name;
                            $tab_url .= '&_wkwc_rma_tab_nonce=' . $tabs_nonce;
                    ?>
                    
                    <li class="router-link-active <?php if($current_tab === $name) { echo 'nav-tab-active'; }{ echo ''; } ?>"><a href="<?php echo esc_url( $tab_url ); ?>"></span><span class="<?php echo esc_html( $tab_data['icon'] ); ?>"></span><span class="menu-name"><?php echo esc_html( $tab_data['label'] ); ?></span></a></li>
                    
                    <?php } ?>
                </ul>
                </div>
        </div>
        <div class="settings-content">
            <h2 role="erp-wp-notice" data-text="Don't remove me, I am super important for admin notice"></h2>
            <?php
            // var_dump($submenu_page . '_content');
            do_action( $submenu_page . '_content', $submenu_name );
            ?>
        </div>
    </div>
</div>