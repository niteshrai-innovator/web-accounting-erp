<?php
/**
 * Admin End Template.
 *
 * @package WooCommerce Product Return RMA
 */

namespace WkAcctErp\Templates\Admin\Views;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Templates\Admin\Form_Template\Settings\General;

if ( ! class_exists( 'WkAcct_Erp_Config_Templates' ) ) {

	/**
	 * Declare Class Admin Template
	 */
	class WkAcct_Erp_Config_Templates {

		/**
		 * Order menu
		 *
		 * @return void
		 */
		public function wkacct_erp_sidebar_tab_menu() {
			$tabs = array(
				'wkacct-erp-config'     => array(
					'label' => esc_html__( 'General', 'wk-acct-erp' ),
					'icon' => 'dashicons dashicons-admin-generic'
				),
				'auto_credit_control'   => array(
					'label' => esc_html__( 'Automatic Credit Control', 'wk-acct-erp' ),
					'icon' => 'dashicons dashicons-admin-plugins'
				),
				'pdf_theme_control'     => array(
					'label' => esc_html__( 'PDF Themes', 'wk-acct-erp' ),
					'icon' => 'dashicons dashicons-pdf'
				),
				'paypal_import_control' => array(
					'label' => esc_html__( 'PayPal Import', 'wk-acct-erp' ),
					'icon' => 'dashicons dashicons-cloud-saved'
				),
			);

			$acct_setting_tabs = apply_filters( 'wkacct_erp_sidebar_tabs_menu', $tabs );

			$this->wkacct_erp_create_setting_template( $acct_setting_tabs );
		}

		public function wkacct_erp_create_setting_template($tabs = array()) {
			$submenu_name = ( is_array( $tabs ) && count( $tabs ) > 0 ) ? array_keys( $tabs )[0] : '';

			$submenu_page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

			if ( ! empty( $submenu_name ) && ! empty( $submenu_page ) && $submenu_name === $submenu_page ) {
				$tab         = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
				$current_tab = empty( $tab ) ? $submenu_name : $tab;

				if ( ! empty( $tab ) ) {
					$submenu_page .= '_' . $tab;
				}

				include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/views/settings/sidebar/sidebar.php';
			}
		}

		public function wkacct_erp_config_general_tabs() {
			$tabs = array(
				'general'     => esc_html__( 'Project Setting', 'wk-acct-erp' ),
				'payment'   => esc_html__( 'Payment Setting', 'wk-acct-erp' ),
				'hmrc_setting'     => esc_html__( 'Hmrc Setting', 'wk-acct-erp' ),
				'vat_setting' => esc_html__( 'Vat Setting', 'wk-acct-erp' ),
			);

			$general_tabs = apply_filters( 'wkacct_erp_general_tabs_menu', $tabs );
			return $general_tabs;
		}

		public function wkacct_erp_config_content() {
			$general_tabs = $this->wkacct_erp_config_general_tabs();
			$general_submenu_name = ( is_array( $general_tabs ) && count( $general_tabs ) > 0 ) ? array_keys( $general_tabs )[0] : '';

			$general_submenu_page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
			$running_tab         = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
			if ( ! empty( $general_submenu_page ) ) {
				$tab         = filter_input( INPUT_GET, 'general-tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
				$current_tab = empty( $tab ) ? $general_submenu_name : $tab;

				if ( ! empty( $tab ) ) {
					$general_submenu_page .= '_' . $tab;
				}
				include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/views/settings/menu/general-menu.php';
			}
		}

	}

}
