<?php
/**
 * Configuration Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
use WkAcctErp\Templates\Admin\Form_Template\Settings\WkAcct_Erp_Config_Template;

if ( ! class_exists( 'WkAcct_Erp_Form_Template' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Form_Template {

		public $config_form;

		/**
		 * Class constructor.
		 */
		public function __construct() {
            $this->config_form = new WkAcct_Erp_Config_Template();
		}

		public function wkacct_erp_config_page_template($submenu){
			$this->config_form->wkacct_erp_general_settings($submenu);
		}

		public function wkacct_erp_config_page_payment_setting($submenu){
			$this->config_form->wkacct_erp_general_payment_settings($submenu);
		}

		public function wkacct_erp_config_page_hmrc_setting($submenu){
			$this->config_form->wkacct_erp_general_hmrc_settings($submenu);
		}

		public function wkacct_erp_config_page_vat_setting($submenu){
			$this->config_form->wkacct_erp_general_vat_settings($submenu);
		}

	}

}
