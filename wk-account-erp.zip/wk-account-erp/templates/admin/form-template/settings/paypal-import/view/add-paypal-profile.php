<div id="wperp-paypal-profile-modal">
   <div class="wperp-container">
      <div role="dialog" class="wperp-modal wperp-modal-open has-form">
         <div class="wperp-modal-dialog">
            <div class="wperp-modal-content">
               <div class="wperp-modal-header">
                  <h3>PayPal Import - New Profile </h3>
                  <span class="modal-close"><i class="dashicons dashicons-no-alt"></i></span>
               </div>
               <div class="wperp-modal-body">
                  <!----> 
                  <form action="" method="post" class="add-pdftheme-form wperp-form-horizontal">
                     <div class="wperp-addon-row">
                        <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><span class="control-tip text-center">Enter your PayPal account email address below to get started:</span></div>
                        <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12 mt-10"><input type="text" required="required" class="wperp-addon-form-field"></div>
                     </div>
                     <div class="submit align-center"><button type="submit" class="wperp-addon-btn button button-primary">Get Started</button></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>