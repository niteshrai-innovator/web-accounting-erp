<?php
/**
 * General Setting Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template\Settings\Paypal_Import;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
if ( ! class_exists( 'WkAcct_Erp_Setting_Paypal_Import' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Setting_Paypal_Import {

		/**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct($submenu) {
			$this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $nonce = isset($this->get_data['_wkacct_erp_general_nonce']) ? sanitize_text_field($this->get_data['_wkacct_erp_general_nonce']) : '';            
            $this->wkacct_erp_setting_paypal_import($submenu);
		}

        public function wkacct_erp_setting_paypal_import($general_submenu_name){ 
			?>
            <div class="content-area wperp-addon-modal">
                <div class="wperp-panel wperp-panel-default panel-paypal-profile">
                    <div class="wperp-panel-heading"><span>Paypal Import</span> <button id="wperp-addon-paypal-profile-new" class="wperp-addon-btn btn--primary add-paypal-trigger"><i class="dashicons dashicons-plus"></i>&nbsp;
                        Add Another Profile
                        </button>
                    </div>
                    <!----> 
                    <div class="wperp-panel-body">
                        <div class="table-container">
                            <div class="">
                            <!----> 
                            <div class="tablenav top">
                                <div class="alignleft actions"></div>
                                <div class="tablenav-pages">
                                    <span class="displaying-num">1 items</span> <!---->
                                </div>
                            </div>
                            <table class="wk-addon-wperp-table table-striped table-dark widefat table2 paypal-profile-list">
                                <thead>
                                    <tr>
                                        <td class="manage-column column-cb check-column col--check">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                        </td>
                                        <th class="column profile column-primary">
                                        Profile
                                        </th>
                                        <th class="column status">
                                        Status
                                        </th>
                                        <th class="column transactions">
                                        Transactions
                                        </th>
                                        <th class="column last_checked">
                                        Last Checked
                                        </th>
                                        <th class="column actions">
                                        Action
                                        </th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <td class="manage-column column-cb check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                        </td>
                                        <th class="column profile column-primary">Profile
                                        </th>
                                        <th class="column status">Status
                                        </th>
                                        <th class="column transactions">Transactions
                                        </th>
                                        <th class="column last_checked">Last Checked
                                        </th>
                                        <th class="column actions">Action
                                        </th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <tr class="">
                                        <th scope="row" class="col--check check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="1"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                        </th>
                                        <td data-colname="Profile" class="column profile column-primary">
                                        gaurav.sharma747@webkul.in
                                        <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                                        </td>
                                        <td data-colname="Status" class="column status">
                                        Enabled
                                        <!----> <!---->
                                        </td>
                                        <td data-colname="Transactions" class="column transactions">
                                        5000
                                        <!----> <!---->
                                        </td>
                                        <td data-colname="Last_checked" class="column last_checked">
                                        2023-08-11 13:11:03
                                        <!----> <!---->
                                        </td>
                                        <td data-colname="Actions" class="column actions">
                                        <!----> <!----> 
                                        <div class="row-actions">
                                            <div class="dropdown wperp-has-dropdown">
                                                <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                                <div class="dropdown-popper dropdown-menu">
                                                    <div x-arrow="" class="popper__arrow"></div>
                                                    <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                                    <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit</a></li>
                                                    <li class="trash"><a href="#"><i class="dashicons dashicons-trash"></i>Delete</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="tablenav bottom">
                                <div class="tablenav-pages">
                                    <span class="displaying-num">1 items</span> <!---->
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       <?php 
        $this->wkacct_erp_paypal_paypal_profile_modal();
        }

        public function wkacct_erp_paypal_paypal_profile_modal(){
            include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/form-template/settings/paypal-import/view/add-paypal-profile.php';
        }

	}

}
