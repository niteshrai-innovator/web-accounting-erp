<?php
/**
 * Configuration Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template\Settings;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Templates\Admin\Form_Template\Settings\General\WkAcct_Erp_Setting_Project;
use WkAcctErp\Templates\Admin\Form_Template\Settings\General\WkAcct_Erp_Setting_Payment;
use WkAcctErp\Templates\Admin\Form_Template\Settings\General\WkAcct_Erp_Setting_Hmrc;
use WkAcctErp\Templates\Admin\Form_Template\Settings\General\WkAcct_Erp_Setting_Vat;
use WkAcctErp\Templates\Admin\Form_Template\Settings\Auto_Credit\WkAcct_Erp_Setting_Auto_Credit;
use WkAcctErp\Templates\Admin\Form_Template\Settings\Pdf_Theme\WkAcct_Erp_Setting_Pdf_Theme;
use WkAcctErp\Templates\Admin\Form_Template\Settings\Paypal_Import\WkAcct_Erp_Setting_Paypal_Import;
use WkAcctErp\Helper;

if ( ! class_exists( 'WkAcct_Erp_Config_Template' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Config_Template {

		/**
		 * Class constructor.
		 */
		public function __construct() {
			
		}

		public function wkacct_erp_general_settings($submenu){
			new WkAcct_Erp_Setting_Project($submenu);
		}

		public function wkacct_erp_general_payment_settings($submenu){
			new WkAcct_Erp_Setting_Payment($submenu);
		}

		public function wkacct_erp_general_hmrc_settings($submenu){
			new WkAcct_Erp_Setting_Hmrc($submenu);
		}

		public function wkacct_erp_general_vat_settings($submenu){
			new WkAcct_Erp_Setting_Vat($submenu);
		}

		public function wkacct_erp_config_auto_credit_control_settings($submenu){
			new WkAcct_Erp_Setting_Auto_Credit($submenu);
		}

		public function wkacct_erp_config_pdf_theme_settings($submenu){
			new WkAcct_Erp_Setting_Pdf_Theme($submenu);
		}

		public function wkacct_erp_config_paypal_import_settings($submenu){
			new WkAcct_Erp_Setting_Paypal_Import($submenu);
		}
	}

}
