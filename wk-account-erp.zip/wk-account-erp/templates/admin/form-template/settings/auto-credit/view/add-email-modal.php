<?php 
defined( 'ABSPATH' ) || exit;
$content = '';
?>
<div id="wperp-email-modal">
    <div class="wperp-container">
        <div role="dialog" class="wperp-modal wperp-modal-open has-form">
            <div class="wperp-modal-dialog">
                <div class="wperp-modal-content">
                <div class="wperp-modal-header">
                    <h3>Add Email</h3>
                    <span class="modal-close"><i class="dashicons dashicons-no-alt"></i></span>
                </div>
                <div class="wperp-modal-body">
                    <!----> 
                    <form method="post" class="add-email-form wperp-form-horizontal" id="wkacct_erp_credit_email_new">
                        <div class="wperp-addon-row">
                            <div class="wperp-addon-col-sm-3 wperp-addon-col-xs-12"><label>Name <span class="wperp-addon-required-sign">*</span></label></div>
                            <div class="wperp-addon-row">
                            <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><input type="text" placeholder="Enter Email Name Here" required="required" class="wperp-addon-form-field"></div>
                            <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><span class="control-tip mt-5">This is only for your own reference. It will never be shown to the customer</span></div>
                            </div>
                        </div>
                        <div class="wperp-addon-row">
                            <div class="wperp-addon-col-sm-3 wperp-addon-col-xs-3"><label>When to send </label> <input type="number" min="1" max="5" placeholder="When to send" required="required" class="wperp-addon-form-field"></div>
                            <div class="wperp-addon-col-sm-9 wperp-addon-col-xs-9">
                            <label>&nbsp;</label> 
                            <select id="before" class="select2 wkaddon-form-field">
                                <option value="0" selected="selected">days after the Sales invoice due date</option>
                                <option value="1">days before the Sales invoice due date</option>
                            </select>
                            </div>
                        </div>
                        <div class="wperp-addon-row">
                            <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><label>Email Subject Line <span class="wperp-addon-required-sign">*</span></label> <input type="text" placeholder="Enter Email Subject Line Here" required="required" class="wperp-addon-form-field"></div>
                        </div>
                        <div class="wperp-addon-row">
                            <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                                <label>Email Body <span class="wperp-addon-required-sign">*</span></label> 

                                <input id="trix_editor" type="hidden" name="trix_content" value="<?php echo esc_attr($content); ?>">
                                <trix-editor input="trix_editor"></trix-editor>

                            </div>
                        </div>
                        <div class="wperp-addon-row">
                            <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><input type="checkbox" id="enable_exist_customer">&nbsp;Disabled - Tick this box and this email wont be sent.
                            </div>
                        </div>
                        <div class="submit align-center"><button type="submit" class="wperp-addon-btn button button-primary">Create Email</button></div>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>
    </div>