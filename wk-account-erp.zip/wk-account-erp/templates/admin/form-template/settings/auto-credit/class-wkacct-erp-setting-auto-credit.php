<?php
/**
 * Auto Credit Setting Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template\Settings\Auto_Credit;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
if ( ! class_exists( 'WkAcct_Erp_Setting_Auto_Credit' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Setting_Auto_Credit {

		/**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct($submenu) {
			$this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $nonce = isset($this->get_data['_wkacct_erp_general_nonce']) ? sanitize_text_field($this->get_data['_wkacct_erp_general_nonce']) : '';
            $this->wkacct_erp_setting_auto_credit($submenu);
		}

        public function wkacct_erp_setting_auto_credit($general_submenu_name){ 
			?>
            <div class="content-area">
                <h2 class="section-title">Automatic Credit Control</h2>
                <div id="erp-addon-settings-<?php echo esc_html($general_submenu_name) ?>" class="settings-box">
                    <!----> 
                    <form action="" enctype="multipart/form-data" method="post" id="credit_control_form" class="credit-control-form">
                        <div class="form-check"><label class="form-check-label"><input type="checkbox" id="erp-addon-enable_auto_credit"> <span class="form-check-sign"><span class="check"></span></span> <span class="form-check-label-light">
                            Enable Automatic Credit Control (Do not worry, no emails will be sent until you have enabled this for specific sales invoices)
                            </span></label>
                        </div>
                        <div class="form-check"><label class="form-check-label"><input type="checkbox" id="erp-addon-enable_all_customer"> <span class="form-check-sign"><span class="check"></span></span> <span class="form-check-label-light">
                            Enable this feature by default for all new customers I add.
                            </span></label>
                        </div>
                        <div class="form-check" style=""><label class="form-check-label"><input type="checkbox" id="erp-addon-enable_exist_customer"> <span class="form-check-sign"><span class="check"></span></span> <span class="form-check-label-light">
                            Turn on this feature for all existing customers
                            </span></label> <label class="form-check-label"><input type="checkbox" id="erp-addon-enable_all_sale"> <span class="form-check-sign"><span class="check"></span></span> <span class="form-check-label-light">
                            Enable Credit Control on all existing sales invoices
                            </span></label>
                        </div>
                        <div class="form-field">
                            <div class="wperp-addon-row">
                                <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                                <label>BCC Address <span class="wperp-addon-required-sign">*</span></label> 
                                <div class="wperp-addon-row">
                                    <div class="wperp-addon-col-sm-4 wperp-addon-col-xs-4"><input type="text" placeholder="Enter BCC Address Here" required="required" class="wperp-addon-form-field"></div>
                                    <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6"><span class="control-tip">Optionally enter an address to be BCC on these emails. You can enter multiple addresses separated by semi-colons.</span></div>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-field">
                            <div class="wperp-addon-row">
                                <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6"><label>From Name <span class="wperp-addon-required-sign">*</span></label> <input type="text" placeholder="Enter From Name Here" required="required" class="wperp-addon-form-field"></div>
                                <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6"><label>From Email <span class="wperp-addon-required-sign">*</span></label> <input type="text" placeholder="Enter From Email Here" required="required" class="wperp-addon-form-field"></div>
                            </div>
                        </div>
                        <div class="form-field">
                            <div class="wperp-addon-row">
                                <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                                <label>Email Signature - This will be appended to all Credit Control emails that are sent <span class="wperp-addon-required-sign">*</span></label> 
                                
                                </div>
                            </div>
                        </div>
                        <div class="form-field">
                            <div class="wperp-addon-row">
                                <div class="wperp-addon-col-sm-3 wperp-addon-col-xs-3">
                                <select class="erp-addon-form-field wkacct-erp-select2" name="wkacct_erp_paypal_account">';
                                    <option value="-1">Select Account</option>
                                    <option value="11am">11am</option>
                                    <option value="2pm">2pm</option>
                                    <option value="5pm">5pm</option>
                                    <option value="8pm">8pm</option>
                                </select>
                                </div>
                                <div class="wperp-addon-col-sm-9 wperp-addon-col-xs-9"><span class="control-tip mt-10">Which time of the day (UK Time) would you like these emails to be sent?</span></div>
                            </div>
                        </div>
                        <div class="submit align-right"><button type="submit" class="wperp-addon-btn button button-primary">Save Changes</button></div>
                    </form>
                </div>
            </div>
       <?php 
            $this->wkacct_erp_auto_credit_control_email();
            $this->wkacct_erp_auto_credit_email_modal();  
        }

        public function wkacct_erp_auto_credit_control_email(){ ?>
            <div class="content-area wperp-addon-modal mt-10">
                <div class="wperp-panel wperp-panel-default panel-email-details">
                    <div class="wperp-panel-heading"><span>Credit Control Emails</span> <button id="wperp-addon-email-format-new" class="wperp-addon-btn btn--primary add-email-trigger"><i class="dashicons dashicons-plus"></i>
                        Add Email
                        </button>
                    </div>
                    <!----> 
                    <div class="wperp-panel-body">
                        <div class="table-container">
                            <div class="">
                            <!----> 
                            <div class="tablenav top">
                                <div class="alignleft actions"></div>
                                <div class="tablenav-pages">
                                    <span class="displaying-num">1 items</span> <!---->
                                </div>
                            </div>
                            <table class="wk-addon-wperp-table table-striped table-dark widefat table2 product-list">
                                <thead>
                                    <tr>
                                        <td class="manage-column column-cb check-column col--check">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                        </td>
                                        <th class="column name column-primary">
                                        Name
                                        </th>
                                        <th class="column when_to_send">
                                        Days
                                        </th>
                                        <th class="column subject_line">
                                        Subject
                                        </th>
                                        <th class="column status">
                                        Status
                                        </th>
                                        <th class="column actions">
                                        </th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <td class="manage-column column-cb check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                        </td>
                                        <th class="column name column-primary">Name
                                        </th>
                                        <th class="column when_to_send">Days
                                        </th>
                                        <th class="column subject_line">Subject
                                        </th>
                                        <th class="column status">Status
                                        </th>
                                        <th class="column actions">
                                        </th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <tr class="">
                                        <th scope="row" class="col--check check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="1"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                        </th>
                                        <td data-colname="Name" class="column name column-primary">
                                        Don't Forgot This Mail
                                        <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                                        </td>
                                        <td data-colname="When_to_send" class="column when_to_send">
                                        2
                                        <!----> <!---->
                                        </td>
                                        <td data-colname="Subject_line" class="column subject_line">
                                        Please Pay This Payment
                                        <!----> <!---->
                                        </td>
                                        <td data-colname="Status" class="column status">
                                        Enabled
                                        <!----> <!---->
                                        </td>
                                        <td data-colname="Actions" class="column actions">
                                        <!----> <!----> 
                                        <div class="row-actions">
                                            <div class="dropdown wperp-has-dropdown">
                                                <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                                <div class="dropdown-popper dropdown-menu">
                                                    <div x-arrow="" class="popper__arrow"></div>
                                                    <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                                    <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit</a></li>
                                                    <li class="trash"><a href="#"><i class="dashicons dashicons-trash"></i>Delete</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="tablenav bottom">
                                <div class="tablenav-pages">
                                    <span class="displaying-num">1 items</span> <!---->
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }

        public function wkacct_erp_auto_credit_email_modal() { 
            include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/form-template/settings/auto-credit/view/add-email-modal.php';
        }

	}

}
