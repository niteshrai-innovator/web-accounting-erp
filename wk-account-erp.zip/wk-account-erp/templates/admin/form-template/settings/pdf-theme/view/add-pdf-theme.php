<div id="wperp-pdftheme-modal">
   <div class="wperp-container">
      <div role="dialog" class="wperp-modal wperp-modal-open has-form">
         <div class="wperp-modal-dialog">
            <div class="wperp-modal-content">
               <div class="wperp-modal-header">
                  <h3>Create a new Theme</h3>
                  <span class="modal-close"><i class="dashicons dashicons-no-alt"></i></span>
               </div>
               <div class="wperp-modal-body">
                  <!----> 
                  <form action="" method="post" class="add-pdftheme-form wperp-form-horizontal">
                     <div class="wperp-addon-row">
                        <div class="wperp-addon-col-sm-3 wperp-addon-col-xs-12"><label>Name <span class="wperp-addon-required-sign">*</span></label></div>
                        <div class="wperp-addon-row">
                           <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><input type="text" placeholder="Enter Theme Name Here" required="required" class="wperp-addon-form-field"></div>
                           <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12"><span class="control-tip mt-5">You create a new theme by copying the HTML template from an existing one. Select which theme to copy from.</span></div>
                        </div>
                     </div>
                     <div class="wperp-addon-row">
                        <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                           <label>Template </label> 
                            <select class="wperp-addon-form-field wkacct-erp-select2" name="wkacct_erp_paypal_account">
                                    <option value="-1">Select Theme Template</option>
                                    <option value="2">Classic Theme Template</option>
                            </select>
                        </div>
                     </div>
                     <div class="submit align-center"><button type="submit" class="wperp-addon-btn button button-primary">Create Theme</button></div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>