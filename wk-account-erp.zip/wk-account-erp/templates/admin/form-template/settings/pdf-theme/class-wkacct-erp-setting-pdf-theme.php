<?php
/**
 * General Setting Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template\Settings\Pdf_Theme;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
if ( ! class_exists( 'WkAcct_Erp_Setting_Pdf_Theme' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Setting_Pdf_Theme {

		/**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct($submenu) {
			$this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $nonce = isset($this->get_data['_wkacct_erp_general_nonce']) ? sanitize_text_field($this->get_data['_wkacct_erp_general_nonce']) : '';            
            $this->wkacct_erp_setting_pdf_theme($submenu);
		}

        public function wkacct_erp_setting_pdf_theme($general_submenu_name){ 
			?>
            <div id="erp-addon-settings-pdf-themes" class="settings-box">
                <div class="wperp-panel wperp-panel-default panel-email-details">
                    <div class="wperp-panel-heading">
                        <h2 class="section-title">Pdf Themes</h2>
                        <button id="wperp-addon-add-new-pdf-theme" class="wperp-addon-btn btn--primary add-email-trigger"><i class="dashicons dashicons-plus"></i>
                        Add New Theme
                        </button>
                    </div>
                    <!----> <!----> 
                    <div class="wperp-panel-body">
                        <div class="pdftheme-outer">
                            <a href="#/pdf_theme_control/edit-theme/1/" class="">
                            <div class="pdftheme-inner">
                                <div class="pdftheme-thumb" style="background-image: url(&quot;https://wpdev.vachak.com/nitesh/wp-content/plugins/wk-wp-erp-addon/assets/images/pdf.png&quot;);"><img src="https://wpdev.vachak.com/nitesh/wp-content/plugins/wk-wp-erp-addon/assets/images/pdf_preview_frame.png"></div>
                                <div class="cl"></div>
                            <a href="#/pdf_theme_control/edit-theme/1/" class="">Classic Pdf Theme</a></div></a> 
                            <div class="active-default-template">Your default theme
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       <?php 
            $this->wkacct_erp_paypal_pdf_theme_modal();
        }

        public function wkacct_erp_paypal_pdf_theme_modal(){
            include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/form-template/settings/pdf-theme/view/add-pdf-theme.php';
        }

	}

}
