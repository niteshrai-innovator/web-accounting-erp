<?php
/**
 * General Setting Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template\Settings\General;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
if ( ! class_exists( 'WkAcct_Erp_Setting_Project' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Setting_Project {

		/**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct($submenu) {
			$this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$nonce = isset($this->get_data['_wkacct_erp_general_nonce']) ? sanitize_text_field($this->get_data['_wkacct_erp_general_nonce']) : '';            
			$this->wkacct_erp_setting_project($submenu);
		}

        public function wkacct_erp_setting_project($general_submenu_name){ 
			$project_data = wkacct_erp()->api->wkacct_erp_get_project_setting();
			
			$project_title = '';
			$project_data_one = '';
			$project_date_two = '';
			$assign_status = '';

			if(isset($project_data['project_title']) && !empty($project_data['project_title'])){
				$project_title = $project_data['project_title'];
			}

			if(isset($project_data['project_date_first']) && !empty($project_data['project_date_first'])){
				$project_data_one = $project_data['project_date_first'];
			}

			if(isset($project_data['project_date_last']) && !empty($project_data['project_date_last'])){
				$project_date_two = $project_data['project_date_last'];
			}

			if(isset($project_data['assign_single_customer']) && !empty($project_data['assign_single_customer'])){
				$assign_status = $project_data['assign_single_customer'];
			}
			?>
				<div id="wkacct-erp-<?php echo esc_html($general_submenu_name) ?>" class="settings-box">
					<span id="wkwp-erp-addon-general-message"></span>
					<form id="wkwp-erp-addon-general-setting-form">
						<table role="presentation" class="form-table">
						<tbody>
							<tr>
								<th scope="row"><label for="project_title">Title</label></th>
								<td>
									<input id="project_title" name="project_title" value="<?php echo esc_attr( $project_title ) ?>" type="text" class="wperp-addon-form-field regular-text"> <span>Rename Projects to anything you like. Use the singular, not the plural - so 'job' instead of 'jobs'.</span>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<hr>
								</td>
							</tr>
							<tr>
								<td colspan="2"><span>You have two date fields, label them anything you like. Leave the names blank to disable them.</span></td>
							</tr>
							<tr>
								<th scope="row"><label for="project_date_first">Date 1</label></th>
								<td><input id="project_date_first" name="project_date_first" type="text" value="<?php echo esc_attr( $project_data_one ) ?>" class="wperp-addon-form-field regular-text"></td>
							</tr>
							<tr>
								<th scope="row"><label for="project_date_last">Date 2</label></th>
								<td><input id="project_date_last" name="project_date_last" type="text" value="<?php echo esc_attr( $project_date_two ) ?>" class="wperp-addon-form-field regular-text"></td>
							</tr>
							<tr>
								<td colspan="2">
									<div class="form-check"><label class="form-check-label"><input type="checkbox" id="erp-erp_pg_paypal_enable_disable" name="assign_single_customer" value="yes" <?php checked( $assign_status, 'yes', true ) ?>> <span class="form-check-sign"><span class="check"></span></span> <span class="form-check-label-light">
									Give me the option to associate a event with a specific customer
									</span></label>
									</div>
								</td>
							</tr>
						</tbody>
						</table>
						<p class="submit">
							<button id="wkacct_general_submit" type="submit" class="wperpaddon-btn btn--primary settings-button">Save Settings</button>
						</p>
					</form>
				</div>
       <?php }

	}

}
