<?php
/**
 * General Setting Template
 *
 * @package WkAcctErp
 * @since 1.0.0
 */
namespace WkAcctErp\Templates\Admin\Form_Template\Settings\General;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Helper;
if ( ! class_exists( 'WkAcct_Erp_Setting_Vat' ) ) {
	/**
	 * Supplier list class
	 */
	class WkAcct_Erp_Setting_Vat {

		/**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct($submenu) {
			$this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $nonce = isset($this->get_data['_wkacct_erp_general_nonce']) ? sanitize_text_field($this->get_data['_wkacct_erp_general_nonce']) : '';
            $this->wkacct_erp_setting_vat_setting($submenu);
		}

        public function wkacct_erp_setting_vat_setting($general_submenu_name){ 
			?>
            <div id="erp-addon-settings-<?php echo esc_html($general_submenu_name) ?>" class="settings-box">
                <h3 class="sub-sub-title">Vat Setting</h3>
                <form action="" enctype="multipart/form-data" method="post" id="vat_setting_form" class="wperp-addon-form">
                    <div class="wperp-addon-row">
                        <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                            <div class="form-check"><label>VAT registration status - I am :<span class="wperp-addon-required-sign">*</span></label> <input type="radio" value="1" checked="checked" class="wperp-addon-form-field-radio"> VAT registered in the UK
                            </div>
                        </div>
                        <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                            <div class="form-field">
                            <label>
                                Enter your VAT registration number. :<span class="wperp-addon-required-sign">*</span>
                                <span class="erp-settings-tooltip">
                                    <svg width="13px" height="13px" viewBox="0 0 13 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <g id="Tooltip" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <g transform="translate(-639.000000, -350.000000)" fill="#CECFD3" fill-rule="nonzero">
                                            <path d="M645.499725,350 C641.910349,350 639,352.910349 639,356.499725 C639,360.089101 641.910349,363 645.499725,363 C649.089101,363 652,360.089101 652,356.499725 C652,352.910349 649.089101,350 645.499725,350 Z M646.852825,360.073693 C646.518265,360.205757 646.251937,360.305905 646.05219,360.375238 C645.852995,360.444571 645.621333,360.479238 645.357757,360.479238 C644.952762,360.479238 644.63746,360.38019 644.412952,360.182646 C644.188444,359.985101 644.076741,359.73473 644.076741,359.430434 C644.076741,359.312127 644.084995,359.191069 644.101503,359.06781 C644.118561,358.94455 644.145524,358.805884 644.182392,358.650159 L644.601143,357.171048 C644.638011,357.029079 644.669926,356.894265 644.695238,356.768804 C644.72055,356.642243 644.732656,356.526138 644.732656,356.420487 C644.732656,356.232296 644.693587,356.100233 644.616,356.025947 C644.537312,355.951661 644.389291,355.915344 644.168635,355.915344 C644.060783,355.915344 643.94963,355.931302 643.835725,355.964868 C643.722921,355.999534 643.624974,356.030899 643.544635,356.061714 L643.655238,355.606095 C643.92927,355.494392 644.191746,355.398646 644.442116,355.319407 C644.692487,355.239069 644.929101,355.19945 645.151958,355.19945 C645.554201,355.19945 645.86455,355.297397 646.083005,355.49109 C646.30036,355.685333 646.409862,355.937905 646.409862,356.248254 C646.409862,356.312635 646.402159,356.425989 646.387302,356.587767 C646.372444,356.750095 646.344381,356.898116 646.303661,357.034032 L645.887111,358.508741 C645.852995,358.627048 645.82273,358.762413 645.795217,358.913735 C645.768254,359.065058 645.755048,359.180614 645.755048,359.258201 C645.755048,359.454095 645.798519,359.58781 645.886561,359.658794 C645.973503,359.729778 646.125926,359.765545 646.34163,359.765545 C646.443429,359.765545 646.557333,359.747386 646.686095,359.712169 C646.813757,359.676952 646.906201,359.645587 646.964529,359.618624 L646.852825,360.073693 Z M646.77909,354.087915 C646.584847,354.268402 646.350984,354.358646 646.077503,354.358646 C645.804571,354.358646 645.569058,354.268402 645.373164,354.087915 C645.17837,353.907429 645.079873,353.687873 645.079873,353.43145 C645.079873,353.175577 645.178921,352.955471 645.373164,352.773333 C645.569058,352.590646 645.804571,352.499852 646.077503,352.499852 C646.350984,352.499852 646.585397,352.590646 646.77909,352.773333 C646.973333,352.955471 647.07073,353.175577 647.07073,353.43145 C647.07073,353.688423 646.973333,353.907429 646.77909,354.087915 Z" id="Shape"></path>
                                        </g>
                                        </g>
                                    </svg>
                                    <span class="tooltiptext">A VAT number is typically a 9 digit number.</span>
                                </span>
                            </label>
                            <input type="text" placeholder="Enter your VAT registration number." class="wperp-addon-form-field">
                            </div>
                        </div>
                        <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6"></div>
                        <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                            <div class="form-field">
                                <label>Select the option that corresponds with the first months of your VAT periods :<span class="wperp-addon-required-sign">*</span></label> 
                                <select class="erp-addon-form-field wkacct-erp-select2" name="wkacct_erp_paypal_account">';
                                    <option value="-1">Select Vat Periods</option>
                                    <option value="Jan, Apr, Jul, Oct">Jan, Apr, Jul, Oct</option>
                                    <option value="Feb, May, Aug, Nov">Feb, May, Aug, Nov</option>
                                    <option value="Mar, Jun, Sep, Dec">Mar, Jun, Sep, Dec</option>
                                </select>
                            </div>
                        </div>
                        <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6"></div>
                        <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                            <button type="submit" class="wperp-addon-btn btn--primary settings-button" style="margin-left: 15px !important;">
                            Save Changes
                            </button> 
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </form>
            </div>
       <?php }

	}

}
