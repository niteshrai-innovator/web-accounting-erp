<div id="event-create-module">
   <div class="wkwp-erp-addon-container">
      <div class="page-header">
         <div class="header-title">
            <h2>Event</h2>
         </div>
      </div>
      <div class="page-body">
         <!----> 
         <form action="" method="post" class="modal-form edit-event-module p-2">
            <div class="form-field-component">
               <div class="event-detail-container">
                  <div class="container-title">
                     Event Details
                  </div>
                  <div class="wperp-addon-row">
                     <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                        <div class="form-field"><label>Name <span class="wperp-addon-required-sign">*</span></label> <input type="text" id="event_name" placeholder="Name" class="wkaddon-form-field"></div>
                     </div>
                     <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                        <div class="form-field"><label>Reference <span class="wperp-addon-required-sign">*</span></label> <input type="text" id="event_name" placeholder="Reference" class="wkaddon-form-field"></div>
                     </div>
                     <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                        <div class="form-field">
                           <label for="event_date_first">Start Date <span class="wkaddon-required-sign">*</span></label> 
                           <input type="text" class="datepicker wkaddon-form-field" name="event_date_first" readonly id="event_date_first">
                        </div>
                     </div>
                     <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                        <div class="form-field">
                           <label for="event_date_last">End Date <span class="wkaddon-required-sign">*</span></label> 
                           <input type="text" class="datepicker wkaddon-form-field" name="event_date_last" readonly id="event_date_last">
                        </div>
                     </div>
                     <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                        <div class="form-field">
                           <label for="event_name">Status <span class="wkaddon-required-sign">*</span></label> 
                            <select class="wkacct-erp-select2" name="event_status">';
                                <option value="-1">Select Status</option>
                                <option value="active">Active</option>
                                <option value="archived">Archived</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                     </div>
                     <!----> 
                     <div class="wperp-addon-col-sm-6 wperp-addon-col-xs-6">
                        <div class="form-field">
                           <div class="wperp-form-group invoice-customers with-multiselect">
                              <label>Vendor <span class="wperp-addon-required-sign">*</span></label> 
                              
                           </div>
                        </div>
                     </div>
                     <div class="wperp-addon-col-sm-12 wperp-addon-col-xs-12">
                        <div class="form-field">
                           <label for="event_summary">Event Summary<span class="wkaddon-required-sign">*</span></label> 
                           <input id="event_summary" type="hidden" name="event_summary" value="<?php echo esc_attr($content); ?>">
                            <trix-editor input="trix_editor"></trix-editor>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="event_report_container">
                  <div class="finance-container">
                     <table role="presentation" class="form-table-right">
                        <tbody>
                           <tr>
                              <th colspan="4" class="container-title">Financials</th>
                           </tr>
                           <tr>
                              <td style="margin-top: 15px; width: 25%;">
                                 Income
                              </td>
                              <td class="form-field" style="width: 40%; text-align: center;"><label for="project_title" style="width: 100%; margin-bottom: 8px !important;">Target </label> <input type="number" step="any" id="event_target" placeholder="Target" required="required" class="wkaddon-form-field"></td>
                              <td class="form-field" style="width: 33%; text-align: center;">
                                 <label for="project_title" style="width: 100%;">Actual </label> 
                                 <p>0</p>
                              </td>
                              <td class="form-field" style="width: 33%; text-align: center;">
                                 <label for="project_title" style="width: 100%;">Difference </label> 
                                 <p style="color: red;">0</p>
                              </td>
                           </tr>
                           <tr>
                              <td style="width: 25%;">
                                 Expenditure
                              </td>
                              <td class="form-field" style="width: 40%;"><input type="number" step="any" id="event_target" placeholder="Target" required="required" class="wkaddon-form-field"></td>
                              <td class="form-field" style="width: 33%; text-align: center;">
                                 <p>0</p>
                              </td>
                              <td class="form-field" style="width: 33%; text-align: center;">
                                 <p style="color: red;">0</p>
                              </td>
                           </tr>
                           <!---->
                        </tbody>
                     </table>
                  </div>
                  <!---->
               </div>
            </div>
            <p class="submit"><button type="submit" class="button button-primary">Create Event</button></p>
         </form>
      </div>
   </div>
</div>