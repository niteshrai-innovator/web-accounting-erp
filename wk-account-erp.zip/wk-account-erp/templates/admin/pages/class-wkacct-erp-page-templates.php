<?php
/**
 * Admin End Template.
 *
 * @package WooCommerce Product Return RMA
 */

namespace WkAcctErp\Templates\Admin\Pages;

defined( 'ABSPATH' ) || exit;

use WkAcctErp\Templates\Admin\Pages\Event;
use WkAcctErp\Templates\Admin\Pages\Product;
use WkAcctErp\Templates\Admin\Pages\Transaction;

if ( ! class_exists( 'WkAcct_Erp_Page_Templates' ) ) {

	/**
	 * Declare Class Admin Template
	 */
	class WkAcct_Erp_Page_Templates {

        public function wkacct_erp_event_page_template(){
            new Event\WkAcct_Erp_Event_Template();
        }

        public function wkacct_erp_event_product_page_template(){
            new Product\WkAcct_Erp_Product_Template();
        }

        public function wkacct_erp_event_transaction_page_template(){
            new Transaction\WkAcct_Erp_Transaction_Template();
        }

        

    }
}