<?php
/**
 * Admin End Template.
 *
 * @package WooCommerce Product Return RMA
 */

namespace WkAcctErp\Templates\Admin\Pages\Transaction;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WkAcct_Erp_Transaction_Template' ) ) {

	/**
	 * Declare Class Admin Template
	 */
	class WkAcct_Erp_Transaction_Template {

        /**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct() {
            $this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if(isset($this->get_data['action']) && !empty($this->get_data['action']) && 'add_new_event' === $this->get_data['action']){
                $this->wkacct_erp_add_event_page_template();
            }else{
                $this->wkacct_erp_event_transaction_page_template();
            }
		}

        public function wkacct_erp_event_transaction_page_template(){ 
            
            ?>
           <div class="wperp-addon-container">
                <div class="content-header-section separator">
                    <div class="wperp-addon-row wperp-between-xs">
                        <div class="wperp-addon-col">
                            <h2 class="content-header__title">Sales Transactions</h2>
                            <div class="wperp-select-container select-primary combo-box">
                            <div class="wperp-selected-option">
                                New Transaction
                                <span class="caret"></span>
                            </div>
                            <ul class="wperp-options">
                                <li>
                                    <a href="#/invoices/new" class="">Create Invoice</a>
                                </li>
                            </ul>
                            <!----> <!---->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wperp-stats wperp-section">
                    <div class="wperp-panel wperp-panel-default">
                        <div class="wperp-panel-body">
                            <div class="wperp-row">
                            <div class="wperp-col-sm-4">
                                <div class="wperp-chart-block has-separator">
                                    <h3>Payment</h3>
                                    <div class="payment-chart">
                                        <div class="chart-container">
                                            <canvas id="payment_chart" hieght="84" width="336" height="186" style="display: block; box-sizing: border-box; height: 93px; width: 168px;"></canvas>
                                        </div>
                                        <div id="payment_legend" class="chart-legend">
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wperp-col-sm-4">
                                <div class="wperp-chart-block has-separator">
                                    <h3>Status</h3>
                                    <div class="payment-chart">
                                        <div class="chart-container">
                                        <canvas id="status_chart" hieght="84" width="336" height="186" style="display: block; box-sizing: border-box; height: 93px; width: 168px;"></canvas>
                                        </div>
                                        <div id="status_legend" class="chart-legend">
                                        <ul class="chart-labels-list">
                                            <li>
                                                <div class="label-icon-wrapper">
                                                    <span class="chart-label-icon" style="background-color:#208DF8"></span>
                                                </div>
                                                <div class="chart-label-values">
                                                    <span class="chart-value">3</span><span class="chart-label"> Awaiting Payment</span>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="label-icon-wrapper">
                                                    <span class="chart-label-icon" style="background-color:#E9485E"></span>
                                                </div>
                                                <div class="chart-label-values">
                                                    <span class="chart-value">1</span><span class="chart-label"> Partially Paid</span>
                                                </div>
                                            </li>
                                        </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wperp-col-sm-4">
                                <div class="wperp-chart-block">
                                    <h3>Outstanding</h3>
                                    <div class="wperp-total">
                                        <h2>$729.14</h2>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wperp-transactions-section wperp-section">
                    <div class="table-container">
                        <div class="">
                            <!----> 
                            <div class="tablenav top">
                            <div class="alignleft actions"></div>
                            <div class="tablenav-pages">
                                <span class="displaying-num">4 items</span> <!---->
                            </div>
                            </div>
                            <table class="wk-addon-wperp-table table-striped table-dark widefat table2 transactions-table">
                            <thead>
                                <tr>
                                    <td class="manage-column column-cb check-column col--check">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                    </td>
                                    <th class="column trn_no column-primary">
                                        Voucher No.
                                    </th>
                                    <th class="column type">
                                        Type
                                    </th>
                                    <th class="column ref">
                                        Ref
                                    </th>
                                    <th class="column customer_name">
                                        Customer
                                    </th>
                                    <th class="column trn_date">
                                        Trn Date
                                    </th>
                                    <th class="column due_date">
                                        Due Date
                                    </th>
                                    <th class="column due">
                                        Balance
                                    </th>
                                    <th class="column amount">
                                        Total
                                    </th>
                                    <th class="column status">
                                        Status
                                    </th>
                                    <th class="column actions">
                                    </th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <td class="manage-column column-cb check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                    </td>
                                    <th class="column trn_no column-primary">Voucher No.
                                    </th>
                                    <th class="column type">Type
                                    </th>
                                    <th class="column ref">Ref
                                    </th>
                                    <th class="column customer_name">Customer
                                    </th>
                                    <th class="column trn_date">Trn Date
                                    </th>
                                    <th class="column due_date">Due Date
                                    </th>
                                    <th class="column due">Balance
                                    </th>
                                    <th class="column amount">Total
                                    </th>
                                    <th class="column status">Status
                                    </th>
                                    <th class="column actions">
                                    </th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <tr class="">
                                    <th scope="row" class="col--check check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="4"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                    </th>
                                    <td data-colname="Trn_no" class="column trn_no column-primary">
                                        <strong><a href="https://wpdev.vachak.com/nitesh/wp-admin/admin.php?page=erp-accounting#/transactions/sales/4">#4</a></strong> <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                                    </td>
                                    <td data-colname="Type" class="column type">
                                        Invoice
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Ref" class="column ref">
                                        -
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Customer_name" class="column customer_name">
                                        Peter Wills
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Trn_date" class="column trn_date">
                                        2023-08-15
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due_date" class="column due_date">
                                        2023-08-20
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due" class="column due">
                                        <span class="dr-balance">Dr. $11.78</span> <!----> <!---->
                                    </td>
                                    <td data-colname="Amount" class="column amount">
                                        $250.78
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Status" class="column status">
                                        Partially Paid
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Actions" class="column actions">
                                        <!----> <!----> 
                                        <div class="row-actions">
                                        <div class="dropdown wk-addon-wperp-has-dropdown">
                                            <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                            <div class="dropdown-popper dropdown-menu">
                                                <div x-arrow="" class="popper__arrow"></div>
                                                <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                                    <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit
                                                    </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="">
                                    <th scope="row" class="col--check check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="3"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                    </th>
                                    <td data-colname="Trn_no" class="column trn_no column-primary">
                                        <strong><a href="https://wpdev.vachak.com/nitesh/wp-admin/admin.php?page=erp-accounting#/transactions/sales/3">#3</a></strong> <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                                    </td>
                                    <td data-colname="Type" class="column type">
                                        Invoice
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Ref" class="column ref">
                                        -
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Customer_name" class="column customer_name">
                                        John Doe
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Trn_date" class="column trn_date">
                                        2023-08-12
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due_date" class="column due_date">
                                        2023-08-20
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due" class="column due">
                                        <span class="dr-balance">Dr. $99.00</span> <!----> <!---->
                                    </td>
                                    <td data-colname="Amount" class="column amount">
                                        $99.00
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Status" class="column status">
                                        Awaiting Payment
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Actions" class="column actions">
                                        <!----> <!----> 
                                        <div class="row-actions">
                                        <div class="dropdown wk-addon-wperp-has-dropdown">
                                            <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                            <div class="dropdown-popper dropdown-menu">
                                                <div x-arrow="" class="popper__arrow"></div>
                                                <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                                    <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit
                                                    </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="">
                                    <th scope="row" class="col--check check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="2"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                    </th>
                                    <td data-colname="Trn_no" class="column trn_no column-primary">
                                        <strong><a href="https://wpdev.vachak.com/nitesh/wp-admin/admin.php?page=erp-accounting#/transactions/sales/2">#2</a></strong> <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                                    </td>
                                    <td data-colname="Type" class="column type">
                                        Invoice
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Ref" class="column ref">
                                        -
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Customer_name" class="column customer_name">
                                        Peter Wills
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Trn_date" class="column trn_date">
                                        2023-08-10
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due_date" class="column due_date">
                                        2023-08-15
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due" class="column due">
                                        <span class="dr-balance">Dr. $369.64</span> <!----> <!---->
                                    </td>
                                    <td data-colname="Amount" class="column amount">
                                        $369.64
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Status" class="column status">
                                        Awaiting Payment
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Actions" class="column actions">
                                        <!----> <!----> 
                                        <div class="row-actions">
                                        <div class="dropdown wk-addon-wperp-has-dropdown">
                                            <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                            <div class="dropdown-popper dropdown-menu">
                                                <div x-arrow="" class="popper__arrow"></div>
                                                <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                                    <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit
                                                    </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="">
                                    <th scope="row" class="col--check check-column">
                                        <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="1"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                                    </th>
                                    <td data-colname="Trn_no" class="column trn_no column-primary">
                                        <strong><a href="https://wpdev.vachak.com/nitesh/wp-admin/admin.php?page=erp-accounting#/transactions/sales/1">#1</a></strong> <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                                    </td>
                                    <td data-colname="Type" class="column type">
                                        Invoice
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Ref" class="column ref">
                                        -
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Customer_name" class="column customer_name">
                                        John Doe
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Trn_date" class="column trn_date">
                                        2023-08-10
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due_date" class="column due_date">
                                        2023-08-20
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Due" class="column due">
                                        <span class="dr-balance">Dr. $248.72</span> <!----> <!---->
                                    </td>
                                    <td data-colname="Amount" class="column amount">
                                        $248.72
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Status" class="column status">
                                        Awaiting Payment
                                        <!----> <!---->
                                    </td>
                                    <td data-colname="Actions" class="column actions">
                                        <!----> <!----> 
                                        <div class="row-actions">
                                        <div class="dropdown wk-addon-wperp-has-dropdown">
                                            <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                            <div class="dropdown-popper dropdown-menu">
                                                <div x-arrow="" class="popper__arrow"></div>
                                                <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                                    <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit
                                                    </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            </table>
                            <div class="tablenav bottom">
                            <div class="tablenav-pages">
                                <span class="displaying-num">4 items</span> <!---->
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }

        public function wkacct_erp_add_event_page_template(){ 
            include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/pages/event/views/add-event.php';
        }

    }
}