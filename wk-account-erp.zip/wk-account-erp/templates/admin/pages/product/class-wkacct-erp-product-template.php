<?php
/**
 * Admin End Template.
 *
 * @package WooCommerce Product Return RMA
 */

namespace WkAcctErp\Templates\Admin\Pages\Product;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WkAcct_Erp_Product_Template' ) ) {

	/**
	 * Declare Class Admin Template
	 */
	class WkAcct_Erp_Product_Template {

        /**
		 * $get_data
		 *
		 * @var $_GET
		 */
		public $get_data;

		/**
		 * $get_data
		 *
		 * @var $_REQUEST
		 */
		public $request_data;

        /**
		 * Class constructor.
		 */
		public function __construct() {
            $this->request_data = isset( $_REQUEST ) ? wc_clean( $_REQUEST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->get_data     = isset( $_GET ) ? wc_clean( $_GET ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if(isset($this->get_data['action']) && !empty($this->get_data['action']) && 'add_new_event' === $this->get_data['action']){
                $this->wkacct_erp_add_event_page_template();
            }else{
                $this->wkacct_erp_event_page_template();
            }
		}

        public function wkacct_erp_event_page_template(){ 
            
            ?>
           <div class="wperp-products">
                <div class="products-header">
                    <h2 class="add-new-product"><span>Products</span> <a href="" id="erp-addon-product-new">Add New</a></h2>
                    <div class="erp-addon-right-action">
                        <div class="erp-addon-btn-group"><button>Import</button> <button>Export</button></div>
                        <div class="product-search" value="">
                            <form>
                            <div class="input-with-addon">
                                <input type="search" placeholder="Search Products" class="wperp-addon-form-field"> <!---->
                            </div>
                            <button type="submit" class="wperp-addon-btn btn--primary search-btn">Search</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!----> <!----> <!----> 
                <div class="">
                    <!----> 
                    <div class="tablenav top">
                        <div class="alignleft actions"></div>
                        <div class="tablenav-pages">
                            <span class="displaying-num">4 items</span> <!---->
                        </div>
                    </div>
                    <table class="wk-addon-wperp-table table-striped table-dark widefat table2 product-list">
                        <thead>
                            <tr>
                            <td class="manage-column column-cb check-column col--check">
                                <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                            </td>
                            <th class="column name column-primary">
                                Product Name
                            </th>
                            <th class="column sale_price">
                                Sale Price
                            </th>
                            <th class="column cost_price">
                                Cost Price
                            </th>
                            <th class="column product_event_name">
                                Event
                            </th>
                            <th class="column vendor_name">
                                Vendor
                            </th>
                            <th class="column actions">
                                Actions
                            </th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                            <td class="manage-column column-cb check-column">
                                <div class="form-check"><label class="form-check-label"><input type="checkbox" class="form-check-input"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                            </td>
                            <th class="column name column-primary">Product Name
                            </th>
                            <th class="column sale_price">Sale Price
                            </th>
                            <th class="column cost_price">Cost Price
                            </th>
                            <th class="column product_event_name">Event
                            </th>
                            <th class="column vendor_name">Vendor
                            </th>
                            <th class="column actions">Actions
                            </th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <tr class="">
                            <th scope="row" class="col--check check-column">
                                <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="4"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                            </th>
                            <td data-colname="Name" class="column name column-primary">
                                Summer Event Product Two
                                <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                            </td>
                            <td data-colname="Sale_price" class="column sale_price">
                                100.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Cost_price" class="column cost_price">
                                150.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Product_event_name" class="column product_event_name">
                                Summer Festival
                                <!----> <!---->
                            </td>
                            <td data-colname="Vendor_name" class="column vendor_name">
                                William Brown
                                <!----> <!---->
                            </td>
                            <td data-colname="Actions" class="column actions">
                                <!----> <!----> 
                                <div class="row-actions">
                                    <div class="dropdown wk-addon-wperp-has-dropdown">
                                        <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                        <div class="dropdown-popper dropdown-menu">
                                        <div x-arrow="" class="popper__arrow"></div>
                                        <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                            <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit</a></li>
                                            <li class="trash"><a href="#"><i class="dashicons dashicons-trash"></i>Delete</a></li>
                                        </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            </tr>
                            <tr class="">
                            <th scope="row" class="col--check check-column">
                                <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="3"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                            </th>
                            <td data-colname="Name" class="column name column-primary">
                                Summer Event Product One
                                <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                            </td>
                            <td data-colname="Sale_price" class="column sale_price">
                                250.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Cost_price" class="column cost_price">
                                499.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Product_event_name" class="column product_event_name">
                                Summer Festival
                                <!----> <!---->
                            </td>
                            <td data-colname="Vendor_name" class="column vendor_name">
                                William Brown
                                <!----> <!---->
                            </td>
                            <td data-colname="Actions" class="column actions">
                                <!----> <!----> 
                                <div class="row-actions">
                                    <div class="dropdown wk-addon-wperp-has-dropdown">
                                        <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                        <div class="dropdown-popper dropdown-menu">
                                        <div x-arrow="" class="popper__arrow"></div>
                                        <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                            <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit</a></li>
                                            <li class="trash"><a href="#"><i class="dashicons dashicons-trash"></i>Delete</a></li>
                                        </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            </tr>
                            <tr class="">
                            <th scope="row" class="col--check check-column">
                                <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="2"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                            </th>
                            <td data-colname="Name" class="column name column-primary">
                                First Event Product Two
                                <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                            </td>
                            <td data-colname="Sale_price" class="column sale_price">
                                139.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Cost_price" class="column cost_price">
                                299.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Product_event_name" class="column product_event_name">
                                Our First Event
                                <!----> <!---->
                            </td>
                            <td data-colname="Vendor_name" class="column vendor_name">
                                -
                                <!----> <!---->
                            </td>
                            <td data-colname="Actions" class="column actions">
                                <!----> <!----> 
                                <div class="row-actions">
                                    <div class="dropdown wk-addon-wperp-has-dropdown">
                                        <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                        <div class="dropdown-popper dropdown-menu">
                                        <div x-arrow="" class="popper__arrow"></div>
                                        <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                            <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit</a></li>
                                            <li class="trash"><a href="#"><i class="dashicons dashicons-trash"></i>Delete</a></li>
                                        </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            </tr>
                            <tr class="">
                            <th scope="row" class="col--check check-column">
                                <div class="form-check"><label class="form-check-label"><input type="checkbox" name="item[]" class="form-check-input" value="1"> <span class="form-check-sign"><span class="check"></span></span></label></div>
                            </th>
                            <td data-colname="Name" class="column name column-primary">
                                First Event Product One
                                <button type="button" class="wk-addon-wperp-toggle-row"><span class="screen-reader-text">Show more details</span></button> <!---->
                            </td>
                            <td data-colname="Sale_price" class="column sale_price">
                                99.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Cost_price" class="column cost_price">
                                199.00
                                <!----> <!---->
                            </td>
                            <td data-colname="Product_event_name" class="column product_event_name">
                                Our First Event
                                <!----> <!---->
                            </td>
                            <td data-colname="Vendor_name" class="column vendor_name">
                                -
                                <!----> <!---->
                            </td>
                            <td data-colname="Actions" class="column actions">
                                <!----> <!----> 
                                <div class="row-actions">
                                    <div class="dropdown wk-addon-wperp-has-dropdown">
                                        <a class="dropdown-trigger"><i class="dashicons-action-menu"></i></a> 
                                        <div class="dropdown-popper dropdown-menu">
                                        <div x-arrow="" class="popper__arrow"></div>
                                        <ul slot="action-items" role="menu" class="horizontal-scroll-wrapper">
                                            <li class="edit"><a href="#"><i class="dashicons dashicons-edit"></i>Edit</a></li>
                                            <li class="trash"><a href="#"><i class="dashicons dashicons-trash"></i>Delete</a></li>
                                        </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="tablenav bottom">
                        <div class="tablenav-pages">
                            <span class="displaying-num">4 items</span> <!---->
                        </div>
                    </div>
                </div>
                </div>
        <?php }

        public function wkacct_erp_add_event_page_template(){ 
            include_once WK_ACCT_ERP_ABSPATH . 'templates/admin/pages/event/views/add-event.php';
        }

    }
}