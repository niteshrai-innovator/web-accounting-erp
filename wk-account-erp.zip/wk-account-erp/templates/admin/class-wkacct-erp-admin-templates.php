<?php
/**
 * Admin End Template.
 *
 * @package WooCommerce Product Return RMA
 */

namespace WkAcctErp\Templates\Admin;


defined( 'ABSPATH' ) || exit;

use WkAcctErp\Templates\Admin\Views;

use WkAcctErp\Templates\Admin\Form_Template as Forms;
use WkAcctErp\Templates\Admin\Pages;

if ( ! class_exists( 'WkAcct_Erp_Admin_Templates' ) ) {

	/**
	 * Declare Class Admin Template
	 */
	class WkAcct_Erp_Admin_Templates {

		protected $config_template;

		protected $form_handler;

		protected $page_template;

		/**
		 * Class constructor.
		 */
		public function __construct() {
			$this->config_template = new Views\WkAcct_Erp_Config_Templates();
			$this->form_handler = new Forms\WkAcct_Erp_Form_Template();
			$this->page_template = new Pages\WkAcct_Erp_Page_Templates();
		}

		/**
		 * Display Attribute Data
		 */
		public function wkacct_erp_configuration_template() {
			$this->config_template->wkacct_erp_sidebar_tab_menu();
		}

		public function wkacct_erp_config_page_template() {
			$this->config_template->wkacct_erp_config_content();
		}


		public function wkacct_erp_config_projects_content($submenu) {
			$this->form_handler->wkacct_erp_config_page_template($submenu);
		}

		public function wkacct_erp_config_payment_content($submenu) {
			$this->form_handler->wkacct_erp_config_page_payment_setting($submenu);
		}

		public function wkacct_erp_config_hmrc_content($submenu) {
			$this->form_handler->wkacct_erp_config_page_hmrc_setting($submenu);
		}

		public function wkacct_erp_config_vat_setting_content($submenu) {
			$this->form_handler->wkacct_erp_config_page_vat_setting($submenu);
		}

		public function wkacct_erp_event_page_template() {
			$this->page_template->wkacct_erp_event_page_template();
		}

		public function wkacct_erp_event_product_page_template() {
			$this->page_template->wkacct_erp_event_product_page_template();
		}

		public function wkacct_erp_event_transaction_page_template() {
			$this->page_template->wkacct_erp_event_transaction_page_template();
		}


	}
}
