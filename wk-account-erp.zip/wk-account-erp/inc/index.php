<?php
/**
 * Silence is golden.
 *
 * @package WooCommerce Product Return RMA
 */
