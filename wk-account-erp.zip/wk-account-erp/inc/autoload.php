<?php
/**
 * This file Dynamically loads classes.
 *
 * @package WooCommerce Product Return RMA
 * @since   1.0.0
 */
namespace WkAcctErp;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

spl_autoload_register( 'WkAcctErp\wk_acct_erp_namespace_class_autoload' );

/**
 * Load class
 *
 * @param string $class_name The name of the class to load.
 */
function wk_acct_erp_namespace_class_autoload( $class_name ) {
	if ( false === strpos( $class_name, 'WkAcctErp' ) ) {
		return;
	}

	$file_parts = explode( '\\', $class_name );

	$namespace = '';

	for ( $i = count( $file_parts ) - 1; $i > 0; $i-- ) {
		$current = strtolower( $file_parts[ $i ] );
		$current = str_ireplace( '_', '-', $current );

		if ( count( $file_parts ) - 1 === $i ) {
			if ( strpos( strtolower( $file_parts[ count( $file_parts ) - 1 ] ), 'interface' ) ) {
				$interface_name = explode( '_', $file_parts[ count( $file_parts ) - 1 ] );

				array_pop( $interface_name );

				$interface_name = strtolower( implode( '-', $interface_name ) );

				$file_name = "interface-$interface_name.php";
			} else {
				$file_name = "class-$current.php";
			}
		} else {
			$namespace = '/' . esc_attr( $current ) . esc_attr( $namespace );
		}

		$filepath  = trailingslashit( dirname( dirname( __FILE__ ) ) . esc_attr( $namespace ) );
		$filepath .= $file_name;
	}

	// If the file exists in the specified path, then include it.
	if ( file_exists( $filepath ) ) {
		include_once $filepath;
	} else {
		wp_die(
			/* translators: %s: is file path */
			sprintf( esc_html__( 'The file attempting to be loaded at %s does not exist.', 'wk-acct-erp' ), esc_attr( $filepath ) )
		);
	}
}
